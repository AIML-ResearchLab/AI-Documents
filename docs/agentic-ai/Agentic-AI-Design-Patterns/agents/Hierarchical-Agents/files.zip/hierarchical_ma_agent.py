"""
Hierarchical Agents Pattern — M&A Due Diligence Platform
=========================================================
Use Case    : Automated M&A Due Diligence for $200M acquisition
Orchestrator: LangGraph  — manages parallel workstream execution
Agent Layer : Google ADK (Gemini) — 3-tier hierarchy:
              Orchestrator → 5 Manager Agents → 15 Worker Agents

Hierarchy
---------
  Orchestrator (M&A Strategy Director)
  ├── Financial Manager  → Revenue Worker, CashFlow Worker, Debt Worker
  ├── Technology Manager → TechDebt Worker, Architecture Worker, Security Worker
  ├── Market Manager     → MarketSize Worker, Competitive Worker, Growth Worker
  ├── Legal Manager      → Patent Worker, Contract Worker, Litigation Worker
  └── Team Manager       → Founder Worker, TeamQuality Worker, Culture Worker

Parallel Execution
------------------
  All 5 Manager workstreams run concurrently via LangGraph parallel branches.
  Each Manager's workers run sequentially within the branch.
  Orchestrator synthesises all 5 results into the final DD report.

Install
-------
  pip install -r requirements.txt
  export GOOGLE_API_KEY="your-gemini-api-key"

Run
---
  python hierarchical_ma_agent.py
"""

from __future__ import annotations

import asyncio
import json
import os
import textwrap
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

# ── LangGraph ──────────────────────────────────────────────────────────────
from langgraph.graph import END, START, StateGraph
from langgraph.checkpoint.memory import MemorySaver

# ── Google ADK / Gemini ────────────────────────────────────────────────────
import google.generativeai as genai
from google.generativeai import GenerativeModel
from google.generativeai.types import FunctionDeclaration, Tool

# ══════════════════════════════════════════════════════════════════════════════
# 0.  Configuration
# ══════════════════════════════════════════════════════════════════════════════

GOOGLE_API_KEY  = os.getenv("GOOGLE_API_KEY", "your-gemini-api-key")
GEMINI_MODEL    = "gemini-1.5-pro"
TARGET_COMPANY  = "TechCorp Inc."
DEAL_SIZE_USD   = 200_000_000

genai.configure(api_key=GOOGLE_API_KEY)


# ══════════════════════════════════════════════════════════════════════════════
# 1.  Simulated Due Diligence Data
#     Realistic simulated data for each workstream.
#     Replace with real APIs (Pitchbook, Crunchbase, SEC EDGAR, etc.)
# ══════════════════════════════════════════════════════════════════════════════

DD_DATA = {

    # ── Financial ────────────────────────────────────────────────────────────
    "revenue": {
        "arr_usd"          : 18_400_000,
        "arr_growth_yoy"   : 0.94,
        "mrr_usd"          : 1_533_333,
        "revenue_3yr"      : [6_200_000, 11_800_000, 18_400_000],
        "revenue_breakdown": {
            "subscriptions": "82%",
            "professional_services": "12%",
            "usage_based": "6%",
        },
        "top_customers": [
            {"name": "Acme Corp",    "arr": 3_200_000, "pct": "17.4%", "churn_risk": "low"},
            {"name": "GlobalTech",   "arr": 2_800_000, "pct": "15.2%", "churn_risk": "medium"},
            {"name": "RetailGiant",  "arr": 2_200_000, "pct": "11.9%", "churn_risk": "low"},
        ],
        "customer_count"    : 342,
        "net_revenue_retention": 118,
    },
    "cash_flow": {
        "fcf_usd"           : 2_100_000,
        "fcf_margin"        : 0.114,
        "cash_on_hand"      : 8_700_000,
        "burn_rate_monthly" : 420_000,
        "runway_months"     : None,   # FCF positive
        "ebitda_usd"        : 2_800_000,
        "ebitda_margin"     : 0.152,
        "gross_margin"      : 0.74,
        "quarters_fcf_positive": 4,
    },
    "debt": {
        "total_debt_usd"    : 4_200_000,
        "debt_breakdown": [
            {"type": "Term loan",    "amount": 3_000_000, "rate": "6.5%", "maturity": "2027"},
            {"type": "Equipment",    "amount": 1_200_000, "rate": "4.2%", "maturity": "2026"},
        ],
        "debt_to_revenue"   : 0.228,
        "debt_to_ebitda"    : 1.5,
        "covenants"         : ["Maintain 1.5x debt coverage", "Min $2M cash"],
        "covenant_breach"   : False,
    },

    # ── Technology ───────────────────────────────────────────────────────────
    "tech_debt": {
        "score"             : 6.2,     # out of 10 (higher = more debt)
        "test_coverage"     : 0.61,
        "code_duplication"  : "14%",
        "outdated_deps"     : 23,
        "critical_outdated" : 4,
        "estimated_remediation_weeks": 12,
        "languages"         : {"Python": "68%", "TypeScript": "24%", "Go": "8%"},
        "notable_issues"    : [
            "Authentication service has 3,200 lines of spaghetti code",
            "No integration tests for payment processing module",
            "Database migrations are manual — no versioning system",
        ],
    },
    "architecture": {
        "style"             : "Microservices",
        "cloud_provider"    : "AWS",
        "regions"           : ["us-east-1", "eu-west-1"],
        "services_count"    : 18,
        "uptime_sla"        : "99.7%",
        "actual_uptime_ytd" : "99.4%",
        "scalability_score" : 7.8,
        "ci_cd"             : True,
        "containerised"     : True,
        "kubernetes"        : True,
        "disaster_recovery" : "Active-passive, 4hr RTO",
        "data_residency"    : "GDPR compliant, EU data in eu-west-1",
    },
    "security": {
        "last_pentest"      : "2024-08-15",
        "critical_cves"     : [
            {
                "id"         : "CVE-2024-1234",
                "severity"   : "CRITICAL",
                "component"  : "auth-service",
                "description": "JWT token validation bypass",
                "patch_available": True,
                "patch_applied"  : False,
            },
            {
                "id"         : "CVE-2024-5678",
                "severity"   : "CRITICAL",
                "component"  : "file-upload",
                "description": "Path traversal vulnerability",
                "patch_available": True,
                "patch_applied"  : False,
            },
        ],
        "high_cves"         : 7,
        "soc2_type2"        : True,
        "iso27001"          : False,
        "data_encryption"   : "AES-256 at rest, TLS 1.3 in transit",
        "secret_scanning"   : True,
        "mfa_enforced"      : True,
    },

    # ── Market ───────────────────────────────────────────────────────────────
    "market_size": {
        "tam_usd_bn"        : 4.2,
        "sam_usd_bn"        : 0.9,
        "som_usd_bn"        : 0.12,
        "market_cagr"       : "16.8%",
        "segment"           : "B2B SaaS — Supply Chain Intelligence",
        "market_stage"      : "Growth",
        "idc_report"        : "IDC 2024: Market to reach $8.4B by 2029",
    },
    "competitive": {
        "position"          : "Challenger",
        "market_share"      : "2.8%",
        "top_competitors"   : [
            {"name": "SupplyLeader",  "share": "31%", "funding": "$240M"},
            {"name": "ChainAI",       "share": "18%", "funding": "$95M"},
            {"name": "LogiSoft",      "share": "12%", "funding": "Public"},
            {"name": "TechCorp Inc.", "share": "2.8%", "funding": "Bootstrapped"},
        ],
        "differentiation"   : [
            "Only solution with real-time IoT integration",
            "3x faster onboarding than SupplyLeader",
            "Patent-pending demand forecasting algorithm",
        ],
        "win_rate"          : "34%",
        "avg_deal_cycle_days": 47,
    },
    "growth": {
        "pipeline_usd"      : 12_400_000,
        "pipeline_coverage" : 3.2,
        "new_logo_ytd"      : 87,
        "expansion_revenue_pct": 0.31,
        "churn_rate_annual" : 0.062,
        "nrr"               : 118,
        "international_pct" : "22%",
        "product_led_growth": True,
        "key_growth_drivers": [
            "EMEA expansion begun Q2 2024",
            "New enterprise tier launched — 3 $500k+ deals in pipeline",
            "API marketplace integration driving viral adoption",
        ],
    },

    # ── Legal ────────────────────────────────────────────────────────────────
    "patents": {
        "granted"           : 3,
        "pending"           : 7,
        "key_patents"       : [
            {"title": "Real-time supply chain anomaly detection", "filed": "2022", "status": "Granted"},
            {"title": "ML-based demand forecasting system",       "filed": "2023", "status": "Pending"},
        ],
        "ip_encumbrances"   : "None identified",
        "open_source_obligations": ["MIT license components — no copyleft issues"],
        "ip_ownership"      : "All IP assigned to company — no founder IP holdback",
    },
    "contracts": {
        "customer_contracts": {
            "avg_length_months": 18.4,
            "auto_renewal_pct" : "73%",
            "price_escalation" : "CPI + 3% annually",
            "termination_for_convenience": "34% of contracts",
        },
        "key_vendor_contracts": [
            {"vendor": "AWS",        "annual": "$820k",  "locked_until": "2026"},
            {"vendor": "Salesforce", "annual": "$140k",  "locked_until": "2025"},
            {"vendor": "Snowflake",  "annual": "$200k",  "locked_until": "2026"},
        ],
        "change_of_control"  : "14 of 342 customer contracts have CoC clauses — $3.1M ARR at risk",
        "employment_contracts": "All employees on standard NDAs and IP assignment",
    },
    "litigation": {
        "active_cases"      : 0,
        "settled_last_3yr"  : [
            {"type": "IP dispute", "settled": "2022", "amount": "$85k", "detail": "Logo trademark dispute"},
        ],
        "regulatory_issues" : "None",
        "gdpr_violations"   : "None",
        "employment_disputes": 0,
        "risk_level"        : "LOW",
    },

    # ── Team ─────────────────────────────────────────────────────────────────
    "founders": {
        "ceo": {
            "name"      : "Sarah Chen",
            "background": "Ex-Google, Stanford MBA, 2 prior exits ($45M, $120M)",
            "equity_pct": "18%",
            "vesting"   : "2yr cliff completed, 1.5yr remaining",
            "intention" : "Committed to 3yr post-acquisition role",
        },
        "cto": {
            "name"      : "Marcus Webb",
            "background": "Ex-Palantir, MIT EECS, filed 4 patents",
            "equity_pct": "14%",
            "vesting"   : "Fully vested",
            "intention" : "Open to departure after 1yr — KEY MAN RISK",
            "replacement_timeline": "9-12 months to hire equivalent",
        },
    },
    "team_quality": {
        "headcount"         : 134,
        "engineering_pct"   : "41%",
        "glassdoor_rating"  : 4.3,
        "voluntary_attrition_annual": "8.2%",
        "key_roles_open"    : 12,
        "critical_dependencies": [
            "CTO Marcus Webb — sole architect of core ML pipeline",
            "Head of Sales — $8.2M pipeline managed by one person",
        ],
        "h1b_dependencies"  : 8,
    },
    "culture": {
        "eNPS"              : 52,
        "remote_policy"     : "Remote-first, optional NYC HQ",
        "diversity": {
            "women_pct"     : "38%",
            "underrep_pct"  : "29%",
        },
        "employee_survey"   : "82% would recommend company",
        "acquisition_sentiment": "Mixed — engineering team concerned about culture fit",
        "retention_risk_post_acq": "MEDIUM — 23% would consider leaving if culture changes",
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# 2.  Worker Tool Functions
#     Each worker has access to specific domain tools.
# ══════════════════════════════════════════════════════════════════════════════

# ── Financial Workers ──────────────────────────────────────────────────────

def fetch_revenue_data(company: str) -> dict:
    """Fetch ARR, growth, revenue breakdown and customer concentration data."""
    return DD_DATA["revenue"]

def analyze_cash_flow(company: str) -> dict:
    """Analyse FCF, burn rate, margins, and runway."""
    return DD_DATA["cash_flow"]

def check_debt_obligations(company: str) -> dict:
    """Review debt structure, covenants, and leverage ratios."""
    return DD_DATA["debt"]

# ── Technology Workers ─────────────────────────────────────────────────────

def scan_tech_debt(company: str) -> dict:
    """Scan codebase for technical debt, test coverage, and outdated dependencies."""
    return DD_DATA["tech_debt"]

def review_architecture(company: str) -> dict:
    """Review system architecture, cloud infrastructure, and scalability."""
    return DD_DATA["architecture"]

def run_security_scan(company: str) -> dict:
    """Run security assessment — CVEs, certifications, encryption, access controls."""
    return DD_DATA["security"]

# ── Market Workers ─────────────────────────────────────────────────────────

def fetch_market_size(company: str, segment: str) -> dict:
    """Fetch TAM/SAM/SOM, market CAGR, and market stage."""
    return DD_DATA["market_size"]

def analyze_competitive_position(company: str) -> dict:
    """Analyse competitive landscape, market share, and differentiation."""
    return DD_DATA["competitive"]

def forecast_growth(company: str) -> dict:
    """Analyse pipeline, churn, NRR, and growth drivers."""
    return DD_DATA["growth"]

# ── Legal Workers ──────────────────────────────────────────────────────────

def review_patents(company: str) -> dict:
    """Review IP portfolio, patent grants, pending applications."""
    return DD_DATA["patents"]

def review_contracts(company: str) -> dict:
    """Review customer contracts, vendor agreements, change-of-control clauses."""
    return DD_DATA["contracts"]

def check_litigation(company: str) -> dict:
    """Check litigation history, regulatory issues, and legal risk level."""
    return DD_DATA["litigation"]

# ── Team Workers ───────────────────────────────────────────────────────────

def profile_founders(company: str) -> dict:
    """Profile founder backgrounds, equity, vesting, and post-acq intentions."""
    return DD_DATA["founders"]

def assess_team_quality(company: str) -> dict:
    """Assess headcount, attrition, key-person dependencies, open roles."""
    return DD_DATA["team_quality"]

def evaluate_culture(company: str) -> dict:
    """Evaluate eNPS, diversity, acquisition sentiment, retention risk."""
    return DD_DATA["culture"]


# Tool registry per workstream
WORKER_TOOLS = {
    "financial" : [fetch_revenue_data, analyze_cash_flow, check_debt_obligations],
    "technology": [scan_tech_debt, review_architecture, run_security_scan],
    "market"    : [fetch_market_size, analyze_competitive_position, forecast_growth],
    "legal"     : [review_patents, review_contracts, check_litigation],
    "team"      : [profile_founders, assess_team_quality, evaluate_culture],
}


# ══════════════════════════════════════════════════════════════════════════════
# 3.  Google ADK Agent — Base Class
# ══════════════════════════════════════════════════════════════════════════════

class GeminiAgent:
    """
    Base ADK agent wrapping Gemini GenerativeModel.
    Supports structured JSON output and multi-turn chat.
    """

    def __init__(
        self,
        name              : str,
        system_instruction: str,
        temperature       : float = 0.2,
    ):
        self.name  = name
        self.model = GenerativeModel(
            model_name         = GEMINI_MODEL,
            system_instruction = system_instruction,
            generation_config  = genai.GenerationConfig(temperature=temperature),
        )

    def run(self, prompt: str) -> str:
        """Run a single prompt and return text."""
        response = self.model.generate_content(prompt)
        return response.text.strip()

    def run_json(self, prompt: str) -> dict:
        """Run prompt expecting JSON response."""
        full_prompt = prompt + "\n\nReturn ONLY valid JSON. No markdown fences, no explanation."
        text = self.run(full_prompt)
        # Strip fences
        clean = text.strip()
        for fence in ["```json", "```"]:
            clean = clean.replace(fence, "")
        clean = clean.strip()
        try:
            return json.loads(clean)
        except json.JSONDecodeError:
            # Extract JSON block
            start = clean.find("{")
            end   = clean.rfind("}") + 1
            if start >= 0 and end > start:
                try:
                    return json.loads(clean[start:end])
                except Exception:
                    pass
            return {"raw": text, "parse_error": True}


# ══════════════════════════════════════════════════════════════════════════════
# 4.  Worker Agent
#     Executes one atomic DD task using domain tools.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class WorkerResult:
    worker_name : str
    domain      : str
    tool_called : str
    raw_data    : dict
    analysis    : str
    risk_flags  : List[str]
    key_findings: List[str]


class WorkerAgent(GeminiAgent):
    """
    Layer 3: Specialist worker agent.
    Calls ONE specific tool, analyses the result, and returns structured findings.
    Knows nothing about the broader acquisition goal.
    """

    def __init__(self, name: str, domain: str, tool_fn: callable, expertise: str):
        super().__init__(
            name = name,
            system_instruction = textwrap.dedent(f"""
                You are a specialist {expertise} analyst conducting M&A due diligence.
                You are given raw data from a single data source.
                Your job:
                1. Analyse the data thoroughly
                2. Identify key findings (both positive and concerning)
                3. Flag any risks clearly with severity (LOW/MEDIUM/HIGH/CRITICAL)
                4. Be specific — cite exact numbers, dates, and names from the data
                5. Do NOT speculate beyond the data provided
                You report only to your Manager — you have no visibility into other workstreams.
            """),
        )
        self.domain   = domain
        self.tool_fn  = tool_fn
        self.tool_name = tool_fn.__name__

    def execute(self, company: str) -> WorkerResult:
        """Call the tool and analyse the result."""
        # Call the tool
        try:
            sig    = self.tool_fn.__code__.co_varnames[:self.tool_fn.__code__.co_argcount]
            kwargs = {"company": company}
            if "segment" in sig:
                kwargs["segment"] = "B2B SaaS"
            raw_data = self.tool_fn(**kwargs)
        except Exception as e:
            raw_data = {"error": str(e)}

        # Analyse with Gemini
        prompt = textwrap.dedent(f"""
            Tool: {self.tool_name}
            Company: {company}

            Raw data returned:
            {json.dumps(raw_data, indent=2, default=str)}

            Provide your analysis as JSON:
            {{
              "key_findings": ["finding 1", "finding 2", "finding 3"],
              "risk_flags": [
                {{"severity": "HIGH", "description": "specific risk with numbers"}},
                ...
              ],
              "analysis": "2-3 paragraph detailed analysis citing specific numbers",
              "score": <0-10 rating for this dimension, 10 = excellent>
            }}
        """)

        data = self.run_json(prompt)

        return WorkerResult(
            worker_name  = self.name,
            domain       = self.domain,
            tool_called  = self.tool_name,
            raw_data     = raw_data,
            analysis     = data.get("analysis", ""),
            risk_flags   = [
                f"[{r.get('severity','?')}] {r.get('description','')}"
                for r in data.get("risk_flags", [])
            ],
            key_findings = data.get("key_findings", []),
        )


# ══════════════════════════════════════════════════════════════════════════════
# 5.  Manager Agent
#     Coordinates workers in one workstream, synthesises their outputs.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ManagerReport:
    domain         : str
    worker_results : List[WorkerResult]
    synthesis      : str
    key_findings   : List[str]
    risk_flags     : List[str]
    recommendation : str
    score          : float       # 0-10 overall domain score
    deal_breaker   : bool


class ManagerAgent(GeminiAgent):
    """
    Layer 2: Manager agent.
    Coordinates 3 worker agents sequentially within its domain.
    Synthesises worker outputs into a domain-level report for the Orchestrator.
    Knows nothing about other managers' workstreams.
    """

    def __init__(self, domain: str, worker_agents: List[WorkerAgent]):
        super().__init__(
            name = f"{domain.title()}Manager",
            system_instruction = textwrap.dedent(f"""
                You are the {domain.title()} Due Diligence Manager at a top private equity firm.
                You oversee a team of specialist analysts who each analyse one aspect of {domain}.
                Your job:
                1. Review all analyst reports from your team
                2. Synthesise findings into a coherent domain-level assessment
                3. Identify cross-cutting themes your analysts may have missed
                4. Flag deal-breakers clearly
                5. Rate the {domain} dimension 0-10 for the acquisition
                6. Provide a clear go/no-go recommendation for your domain
                You report only to the M&A Director. You do not communicate with other managers.
            """),
        )
        self.domain  = domain
        self.workers = worker_agents

    def run_workstream(self, company: str) -> ManagerReport:
        """Execute all workers sequentially, then synthesise."""
        print(f"\n  [{self.domain.upper()} MANAGER] Starting workstream...")

        # ── Run workers sequentially ──────────────────────────────────────
        worker_results: List[WorkerResult] = []
        for worker in self.workers:
            print(f"    ⚡ Worker: {worker.name} → {worker.tool_name}()")
            result = worker.execute(company)
            worker_results.append(result)
            print(f"       Findings: {len(result.key_findings)} | Risks: {len(result.risk_flags)}")

        # ── Synthesise with Gemini ────────────────────────────────────────
        workers_summary = "\n\n".join([
            f"--- {r.worker_name} ({r.tool_called}) ---\n"
            f"Key Findings: {json.dumps(r.key_findings)}\n"
            f"Risk Flags: {json.dumps(r.risk_flags)}\n"
            f"Analysis: {r.analysis[:500]}"
            for r in worker_results
        ])

        prompt = textwrap.dedent(f"""
            Company: {company}
            Your Domain: {self.domain.title()} Due Diligence

            Worker Reports from Your Team:
            {workers_summary}

            Synthesise into a domain-level manager report as JSON:
            {{
              "synthesis": "3-4 paragraph executive-level synthesis of all findings",
              "key_findings": ["top finding 1", "top finding 2", ...],
              "risk_flags": [
                {{"severity": "CRITICAL|HIGH|MEDIUM|LOW", "description": "...", "mitigation": "..."}}
              ],
              "recommendation": "PROCEED|PROCEED_WITH_CONDITIONS|DO_NOT_PROCEED",
              "recommendation_rationale": "why",
              "score": <0-10>,
              "deal_breaker": <true|false>,
              "deal_breaker_reason": "if true, explain"
            }}
        """)

        data = self.run_json(prompt)

        all_risks = []
        for r in data.get("risk_flags", []):
            all_risks.append(f"[{r.get('severity','?')}] {r.get('description','')} → {r.get('mitigation','')}")

        report = ManagerReport(
            domain         = self.domain,
            worker_results = worker_results,
            synthesis      = data.get("synthesis", ""),
            key_findings   = data.get("key_findings", []),
            risk_flags     = all_risks,
            recommendation = data.get("recommendation", "PROCEED_WITH_CONDITIONS"),
            score          = float(data.get("score", 5.0)),
            deal_breaker   = bool(data.get("deal_breaker", False)),
        )

        print(f"\n  [{self.domain.upper()} MANAGER] ✅ Complete")
        print(f"    Score: {report.score:.1f}/10 | Rec: {report.recommendation}")
        if report.deal_breaker:
            print(f"    ⛔ DEAL BREAKER FLAGGED")

        return report


# ══════════════════════════════════════════════════════════════════════════════
# 6.  Orchestrator Agent
#     Top-level agent. Decomposes goal, coordinates managers, synthesises report.
# ══════════════════════════════════════════════════════════════════════════════

class OrchestratorAgent(GeminiAgent):
    """
    Layer 1: Orchestrator (M&A Strategy Director).
    Receives the acquisition goal.
    Coordinates all 5 manager workstreams (via LangGraph parallel execution).
    Synthesises all manager reports into the final DD report and recommendation.
    Never calls tools directly.
    """

    def __init__(self):
        super().__init__(
            name = "OrchestratorAgent",
            system_instruction = textwrap.dedent("""
                You are the Managing Director of M&A Strategy at a top-tier private equity firm.
                You oversee full due diligence processes for acquisitions up to $500M.

                You receive reports from 5 specialist managers:
                Financial, Technology, Market, Legal, and Team.

                Your job:
                1. Synthesise all domain reports into a board-level DD report
                2. Identify cross-domain risks (e.g. tech debt + key-man = compounded risk)
                3. Assess deal-breakers holistically — one domain's red flag can kill the deal
                4. Provide a final valuation opinion and deal structure recommendation
                5. Draft acquisition conditions if proceeding

                You are authoritative, precise, and data-driven.
                Your recommendation will determine whether $200M is deployed.
            """),
            temperature = 0.1,  # Low temp for high-stakes final synthesis
        )

    def synthesise(
        self,
        company         : str,
        deal_size_usd   : int,
        manager_reports : Dict[str, ManagerReport],
    ) -> str:
        """Synthesise all manager reports into the final DD report."""

        reports_text = ""
        for domain, report in manager_reports.items():
            reports_text += textwrap.dedent(f"""
            ═══ {domain.upper()} DUE DILIGENCE ═══
            Score: {report.score:.1f}/10
            Recommendation: {report.recommendation}
            Deal Breaker: {report.deal_breaker}

            Synthesis:
            {report.synthesis[:600]}

            Key Findings:
            {json.dumps(report.key_findings, indent=2)}

            Risk Flags:
            {json.dumps(report.risk_flags[:5], indent=2)}

            """)

        scores        = {d: r.score for d, r in manager_reports.items()}
        deal_breakers = [d for d, r in manager_reports.items() if r.deal_breaker]
        avg_score     = sum(scores.values()) / len(scores)

        prompt = textwrap.dedent(f"""
            TARGET COMPANY: {company}
            PROPOSED DEAL SIZE: ${deal_size_usd:,}
            CURRENT ARR: $18,400,000
            ARR MULTIPLE IMPLIED: {deal_size_usd / 18_400_000:.1f}x

            DOMAIN SCORES:
            {json.dumps(scores, indent=2)}
            AVERAGE SCORE: {avg_score:.1f}/10
            DEAL BREAKERS FLAGGED: {deal_breakers if deal_breakers else 'None'}

            ALL MANAGER REPORTS:
            {reports_text}

            Write the complete M&A Due Diligence Report with these sections:

            # M&A Due Diligence Report: {company}
            ## Executive Summary
            ## Investment Thesis
            ## Domain Scorecard
            ## Key Strengths
            ## Key Risks & Mitigations
            ## Cross-Domain Risk Analysis
            ## Valuation Assessment (${deal_size_usd:,} vs market comps)
            ## Deal Structure Recommendations
            ## Acquisition Conditions (if proceeding)
            ## Final Recommendation: PROCEED / PROCEED WITH CONDITIONS / DO NOT PROCEED
            ## Board Summary (3 bullets max)

            Be specific. Cite exact numbers. This goes to the investment committee.
        """)

        return self.run(prompt)


# ══════════════════════════════════════════════════════════════════════════════
# 7.  Agent Factory — Build the Full Hierarchy
# ══════════════════════════════════════════════════════════════════════════════

def build_agent_hierarchy() -> Tuple[OrchestratorAgent, Dict[str, ManagerAgent]]:
    """
    Construct the full 3-tier agent hierarchy:
      Orchestrator → 5 Managers → 15 Workers (3 per manager)
    """

    # ── Workers ───────────────────────────────────────────────────────────
    workers = {
        "financial": [
            WorkerAgent("RevenueAnalyst",   "financial", fetch_revenue_data,          "revenue & ARR"),
            WorkerAgent("CashFlowAnalyst",  "financial", analyze_cash_flow,           "cash flow & margins"),
            WorkerAgent("DebtAnalyst",      "financial", check_debt_obligations,      "debt & leverage"),
        ],
        "technology": [
            WorkerAgent("TechDebtAnalyst",  "technology", scan_tech_debt,             "technical debt"),
            WorkerAgent("ArchAnalyst",      "technology", review_architecture,        "system architecture"),
            WorkerAgent("SecurityAnalyst",  "technology", run_security_scan,          "cybersecurity"),
        ],
        "market": [
            WorkerAgent("MarketAnalyst",    "market",    fetch_market_size,           "market sizing"),
            WorkerAgent("CompAnalyst",      "market",    analyze_competitive_position,"competitive strategy"),
            WorkerAgent("GrowthAnalyst",    "market",    forecast_growth,             "growth & pipeline"),
        ],
        "legal": [
            WorkerAgent("PatentAnalyst",    "legal",     review_patents,              "IP & patents"),
            WorkerAgent("ContractAnalyst",  "legal",     review_contracts,            "contracts & agreements"),
            WorkerAgent("LitigationAnalyst","legal",     check_litigation,            "litigation & compliance"),
        ],
        "team": [
            WorkerAgent("FounderAnalyst",   "team",      profile_founders,            "founder assessment"),
            WorkerAgent("TeamAnalyst",      "team",      assess_team_quality,         "team quality & retention"),
            WorkerAgent("CultureAnalyst",   "team",      evaluate_culture,            "culture & engagement"),
        ],
    }

    # ── Managers ──────────────────────────────────────────────────────────
    managers = {
        domain: ManagerAgent(domain, domain_workers)
        for domain, domain_workers in workers.items()
    }

    # ── Orchestrator ──────────────────────────────────────────────────────
    orchestrator = OrchestratorAgent()

    return orchestrator, managers


# ══════════════════════════════════════════════════════════════════════════════
# 8.  LangGraph State
# ══════════════════════════════════════════════════════════════════════════════

class DDState(dict):
    """
    Keys
    ----
    company          : str — target company name
    deal_size_usd    : int — proposed deal value
    manager_reports  : Dict[str, ManagerReport] — populated by parallel branches
    final_report     : str | None
    phase            : str
    errors           : List[str]
    """


def make_initial_state(company: str, deal_size: int) -> DDState:
    return DDState(
        company         = company,
        deal_size_usd   = deal_size,
        manager_reports = {},
        final_report    = None,
        phase           = "init",
        errors          = [],
    )


# ══════════════════════════════════════════════════════════════════════════════
# 9.  LangGraph Node Functions
# ══════════════════════════════════════════════════════════════════════════════

# Global agent hierarchy (built once)
ORCHESTRATOR, MANAGERS = build_agent_hierarchy()


def _run_manager(domain: str, company: str) -> Tuple[str, ManagerReport]:
    """Helper — runs one manager workstream, returns (domain, report)."""
    return domain, MANAGERS[domain].run_workstream(company)


def node_parallel_workstreams(state: DDState) -> DDState:
    """
    Run all 5 manager workstreams in parallel using ThreadPoolExecutor.
    LangGraph executes this as a single node; parallelism is internal.
    """
    company = state["company"]

    print(f"\n{'═'*65}")
    print(f"  PHASE: PARALLEL WORKSTREAMS")
    print(f"  Launching 5 manager workstreams simultaneously...")
    print(f"{'═'*65}")

    domains  = ["financial", "technology", "market", "legal", "team"]
    reports  = {}
    errors   = []

    # ── Parallel execution via ThreadPoolExecutor ─────────────────────────
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {
            executor.submit(_run_manager, domain, company): domain
            for domain in domains
        }

        for future in as_completed(futures):
            domain = futures[future]
            try:
                domain_name, report = future.result()
                reports[domain_name] = report
                print(f"\n  ✅ [{domain_name.upper()}] Workstream complete "
                      f"(score={report.score:.1f}/10)")
            except Exception as e:
                errors.append(f"{domain}: {str(e)}")
                print(f"\n  ❌ [{domain.upper()}] Failed: {e}")

    return {
        **state,
        "manager_reports": reports,
        "errors"         : errors,
        "phase"          : "workstreams_complete",
    }


def node_orchestrate(state: DDState) -> DDState:
    """
    Orchestrator synthesises all manager reports into the final DD report.
    """
    print(f"\n{'═'*65}")
    print(f"  PHASE: ORCHESTRATOR SYNTHESIS")
    print(f"{'═'*65}")

    company  = state["company"]
    reports  = state["manager_reports"]
    deal_sz  = state["deal_size_usd"]

    # Print domain scorecard
    print(f"\n  Domain Scorecard:")
    total = 0
    deal_breakers = []
    for domain, report in sorted(reports.items()):
        icon = "⛔" if report.deal_breaker else "✅"
        print(f"  {icon} {domain.upper():12s}: {report.score:.1f}/10  [{report.recommendation}]")
        total += report.score
        if report.deal_breaker:
            deal_breakers.append(domain)

    avg = total / len(reports) if reports else 0
    print(f"\n  Average Score: {avg:.1f}/10")
    if deal_breakers:
        print(f"  ⛔ Deal Breakers: {deal_breakers}")

    print(f"\n  🤖 Orchestrator synthesising final report...")
    final_report = ORCHESTRATOR.synthesise(company, deal_sz, reports)

    return {
        **state,
        "final_report": final_report,
        "phase"       : "complete",
    }


def node_deliver(state: DDState) -> DDState:
    """Print and save the final report."""
    print(f"\n{'═'*65}")
    print(f"  FINAL DUE DILIGENCE REPORT")
    print(f"{'═'*65}\n")
    print(state["final_report"])

    if state["errors"]:
        print(f"\n⚠️  Errors during execution:")
        for e in state["errors"]:
            print(f"  - {e}")

    return state


# ══════════════════════════════════════════════════════════════════════════════
# 10. Build LangGraph State Machine
# ══════════════════════════════════════════════════════════════════════════════

def build_dd_graph():
    """
    M&A Due Diligence Graph:

        START
          │
          ▼
    parallel_workstreams   ← All 5 managers run concurrently here
    (Financial + Tech +        (ThreadPoolExecutor inside this node)
     Market + Legal + Team)
          │
          ▼
      orchestrate           ← Synthesise all 5 manager reports
          │
          ▼
        deliver             ← Print + save final report
          │
          ▼
         END
    """
    builder = StateGraph(DDState)

    builder.add_node("parallel_workstreams", node_parallel_workstreams)
    builder.add_node("orchestrate",          node_orchestrate)
    builder.add_node("deliver",              node_deliver)

    builder.add_edge(START,                  "parallel_workstreams")
    builder.add_edge("parallel_workstreams", "orchestrate")
    builder.add_edge("orchestrate",          "deliver")
    builder.add_edge("deliver",              END)

    return builder.compile()


# ══════════════════════════════════════════════════════════════════════════════
# 11. Public API
# ══════════════════════════════════════════════════════════════════════════════

def run_ma_due_diligence(
    company     : str = TARGET_COMPANY,
    deal_size   : int = DEAL_SIZE_USD,
) -> Dict[str, Any]:
    """
    Run full M&A due diligence using hierarchical agents.

    Args:
        company   : Target company name
        deal_size : Proposed deal value in USD

    Returns:
        Final state with complete DD report and all manager reports
    """
    print("═" * 65)
    print("  Hierarchical M&A Due Diligence Agent")
    print("  LangGraph + Google ADK (Gemini)")
    print("═" * 65)
    print(f"\n  Target  : {company}")
    print(f"  Deal    : ${deal_size:,}")
    print(f"  ARR     : $18,400,000")
    print(f"  Multiple: {deal_size/18_400_000:.1f}x ARR")
    print(f"\n  Hierarchy:")
    print(f"  Layer 1: 1 Orchestrator (M&A Strategy Director)")
    print(f"  Layer 2: 5 Managers (Financial/Tech/Market/Legal/Team)")
    print(f"  Layer 3: 15 Workers (3 per Manager)")
    print(f"  Execution: 5 workstreams run in PARALLEL")

    graph         = build_dd_graph()
    initial_state = make_initial_state(company, deal_size)
    final_state   = graph.invoke(initial_state)

    return final_state


# ══════════════════════════════════════════════════════════════════════════════
# 12. Entry Point
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    start_time  = datetime.now()
    final_state = run_ma_due_diligence(TARGET_COMPANY, DEAL_SIZE_USD)
    elapsed     = (datetime.now() - start_time).total_seconds()

    print(f"\n\n{'═'*65}")
    print(f"  EXECUTION SUMMARY")
    print(f"{'═'*65}")
    print(f"  Total time   : {elapsed:.1f}s")
    print(f"  Agents used  : 1 Orchestrator + 5 Managers + 15 Workers = 21 total")
    print(f"  Parallelism  : 5 workstreams ran concurrently")

    # Save outputs
    if final_state.get("final_report"):
        report_path = "ma_dd_report.md"
        header = textwrap.dedent(f"""
            # M&A Due Diligence Report
            **Target:** {TARGET_COMPANY}
            **Deal Size:** ${DEAL_SIZE_USD:,}
            **Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}
            **Agent:** Hierarchical Agents (LangGraph + Google ADK)
            ---
        """)
        with open(report_path, "w") as f:
            f.write(header + "\n" + final_state["final_report"])
        print(f"\n  📄 Full report saved to: {report_path}")

    # Save domain scorecards
    scorecards = {}
    for domain, report in final_state.get("manager_reports", {}).items():
        scorecards[domain] = {
            "score"         : report.score,
            "recommendation": report.recommendation,
            "deal_breaker"  : report.deal_breaker,
            "key_findings"  : report.key_findings[:3],
            "risk_flags"    : report.risk_flags[:3],
        }

    with open("domain_scorecards.json", "w") as f:
        json.dump(scorecards, f, indent=2)
    print(f"  📊 Domain scorecards saved to: domain_scorecards.json")

    # Save worker-level findings
    worker_log = []
    for domain, report in final_state.get("manager_reports", {}).items():
        for wr in report.worker_results:
            worker_log.append({
                "domain"      : domain,
                "worker"      : wr.worker_name,
                "tool"        : wr.tool_called,
                "findings"    : wr.key_findings,
                "risks"       : wr.risk_flags,
            })

    with open("worker_findings.json", "w") as f:
        json.dump(worker_log, f, indent=2)
    print(f"  🔍 Worker findings saved to: worker_findings.json")
