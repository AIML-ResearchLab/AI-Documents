# Hierarchical M&A Due Diligence Agent
## LangGraph + Google ADK (Gemini)

---

## The 3-Tier Hierarchy

```
Layer 1: ORCHESTRATOR (1 agent)
│   M&A Strategy Director
│   → Decomposes goal, coordinates managers, synthesises final report
│   → Never calls tools directly
│
├── Layer 2: MANAGERS (5 agents, parallel)
│   │   Each owns one domain workstream
│   │   → Breaks domain into atomic tasks
│   │   → Coordinates workers, synthesises domain report
│   │   → Reports only to Orchestrator
│   │
│   ├── FinancialManager
│   │   ├── Layer 3: RevenueAnalyst    → fetch_revenue_data()
│   │   ├── Layer 3: CashFlowAnalyst  → analyze_cash_flow()
│   │   └── Layer 3: DebtAnalyst      → check_debt_obligations()
│   │
│   ├── TechnologyManager
│   │   ├── Layer 3: TechDebtAnalyst  → scan_tech_debt()
│   │   ├── Layer 3: ArchAnalyst      → review_architecture()
│   │   └── Layer 3: SecurityAnalyst  → run_security_scan()
│   │
│   ├── MarketManager
│   │   ├── Layer 3: MarketAnalyst    → fetch_market_size()
│   │   ├── Layer 3: CompAnalyst      → analyze_competitive_position()
│   │   └── Layer 3: GrowthAnalyst    → forecast_growth()
│   │
│   ├── LegalManager
│   │   ├── Layer 3: PatentAnalyst    → review_patents()
│   │   ├── Layer 3: ContractAnalyst  → review_contracts()
│   │   └── Layer 3: LitigationAnalyst→ check_litigation()
│   │
│   └── TeamManager
│       ├── Layer 3: FounderAnalyst   → profile_founders()
│       ├── Layer 3: TeamAnalyst      → assess_team_quality()
│       └── Layer 3: CultureAnalyst   → evaluate_culture()
```

**Total agents: 21 (1 + 5 + 15)**

---

## LangGraph State Machine

```
START → parallel_workstreams → orchestrate → deliver → END
              │
              └── ThreadPoolExecutor runs 5 managers concurrently
                  Each manager runs 3 workers sequentially
```

Parallelism is implemented inside the `parallel_workstreams` node using
`ThreadPoolExecutor(max_workers=5)` — all 5 manager workstreams execute
simultaneously, reducing wall-clock time by ~3.5×.

---

## Chain of Command Protocol

```
ALLOWED:                          FORBIDDEN:
Orchestrator ↔ Manager  ✅        Worker  → Orchestrator  ❌
Manager      ↔ Worker   ✅        Worker  → Worker         ❌
                                  Orchestrator → Worker   ❌
```

Scope isolation means a failure in Legal doesn't affect Technology.
Each domain is fully self-contained.

---

## Parallelism Impact

```
Sequential (no hierarchy):
Financial (15min) → Tech → Market → Legal → Team = 63 min

Parallel (hierarchical):
Financial │▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓│ 15min
Tech      │▓▓▓▓▓▓▓▓▓▓▓▓│
Market    │▓▓▓▓▓▓▓▓▓▓│         → All simultaneous
Legal     │▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓│ 18min (bottleneck)
Team      │▓▓▓▓▓▓▓▓│
                              = 18min + synthesis
Speed gain: 3.5×
```

---

## Setup & Run

```bash
pip install -r requirements.txt
export GOOGLE_API_KEY="your-gemini-api-key"
python hierarchical_ma_agent.py
```

**Outputs:**
- `ma_dd_report.md`         — Full board-level DD report
- `domain_scorecards.json`  — Score, recommendation, and top risks per domain
- `worker_findings.json`    — All 15 worker findings and risk flags

---

## Usage in Code

```python
from hierarchical_ma_agent import run_ma_due_diligence

state = run_ma_due_diligence(
    company   = "AcquireTarget Inc.",
    deal_size = 150_000_000,
)

print(state["final_report"])

# Access individual domain reports
fin_report = state["manager_reports"]["financial"]
print(f"Financial score: {fin_report.score}/10")
print(f"Deal breaker: {fin_report.deal_breaker}")
```

---

## Adapting to Real Data Sources

Replace the simulated tool functions with real API calls:

```python
def fetch_revenue_data(company: str) -> dict:
    # Replace with real Pitchbook / Crunchbase API
    return pitchbook_client.get_financials(company)

def run_security_scan(company: str) -> dict:
    # Replace with Qualys / Snyk / Wiz API
    return snyk_client.get_vulnerabilities(company)

def check_litigation(company: str) -> dict:
    # Replace with PACER / Westlaw API
    return westlaw_client.search_cases(company)
```

---

## Extending the Hierarchy

Add a new domain (e.g. ESG Due Diligence) in 3 steps:

```python
# 1. Add worker tools
def assess_carbon_footprint(company): ...
def review_esg_ratings(company): ...
def check_regulatory_compliance(company): ...

# 2. Create workers
esg_workers = [
    WorkerAgent("CarbonAnalyst",     "esg", assess_carbon_footprint, "carbon"),
    WorkerAgent("ESGRatingAnalyst",  "esg", review_esg_ratings,      "ESG ratings"),
    WorkerAgent("ComplianceAnalyst", "esg", check_regulatory_compliance, "compliance"),
]

# 3. Create manager and add to hierarchy
MANAGERS["esg"] = ManagerAgent("esg", esg_workers)
# That's it — LangGraph parallel node picks it up automatically
```

---

## Pattern Comparison

| | ReAct | PAR | Reflexion | Hyp. Test | **Hierarchical** |
|---|---|---|---|---|---|
| Multi-agent | ❌ | ❌ | ❌ | ❌ | ✅ |
| Parallel execution | ❌ | ✅ | ❌ | ❌ | ✅ |
| Chain of command | ❌ | ❌ | ❌ | ❌ | ✅ |
| Domain isolation | ❌ | ❌ | ❌ | ❌ | ✅ |
| Scales with task size | ❌ | ❌ | ❌ | ❌ | ✅ |
| Best for | Research | Workflows | Debugging | Diagnosis | **Complex multi-domain** |
