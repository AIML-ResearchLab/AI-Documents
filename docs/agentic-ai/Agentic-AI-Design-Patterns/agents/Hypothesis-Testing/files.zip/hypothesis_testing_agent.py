"""
Hypothesis Testing Agentic Pattern
====================================
Use Case    : Automated Production Incident Diagnosis
Orchestrator: LangGraph  — manages the Hypothesize→Design→Experiment→Update loop
Agent Layer : Google ADK  — specialist agents with registered tool functions
Pattern     : Scientific method — form hypotheses, design experiments to falsify,
              update confidence scores, conclude when threshold is reached

Hypothesis Testing Loop
-----------------------
  HYPOTHESIZE  →  DESIGN EXPERIMENT  →  RUN EXPERIMENT
       ↑                                      │
       └──── UPDATE BELIEFS ←─────────────────┘
                    │
             confidence ≥ threshold?
                    │
                   YES → CONCLUDE

Install
-------
  pip install -r requirements.txt
  export GOOGLE_API_KEY="your-gemini-api-key"

Run
---
  python hypothesis_testing_agent.py
"""

from __future__ import annotations

import json
import os
import random
import textwrap
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

# ── LangGraph ──────────────────────────────────────────────────────────────
from langgraph.graph import END, START, StateGraph

# ── Google ADK ─────────────────────────────────────────────────────────────
import google.generativeai as genai
from google.generativeai import GenerativeModel
from google.generativeai.types import FunctionDeclaration, Tool

# ══════════════════════════════════════════════════════════════════════════════
# 0.  Configuration
# ══════════════════════════════════════════════════════════════════════════════

GOOGLE_API_KEY         = os.getenv("GOOGLE_API_KEY", "your-gemini-api-key")
GEMINI_MODEL           = "gemini-1.5-pro"
CONFIDENCE_THRESHOLD   = 0.85    # conclude when top hypothesis reaches this
MAX_EXPERIMENTS        = 8       # hard cap on experiment count
MIN_EXPERIMENTS        = 2       # run at least this many before concluding

genai.configure(api_key=GOOGLE_API_KEY)


# ══════════════════════════════════════════════════════════════════════════════
# 1.  Core Data Structures
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Hypothesis:
    id          : str
    statement   : str
    confidence  : float          # 0.0 – 1.0
    status      : str = "active" # active | confirmed | falsified
    evidence_for: List[str] = field(default_factory=list)
    evidence_against: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "id"        : self.id,
            "statement" : self.statement,
            "confidence": round(self.confidence, 3),
            "status"    : self.status,
        }


@dataclass
class Experiment:
    number      : int
    target_hyp  : str            # hypothesis ID being tested
    rationale   : str            # why this experiment discriminates
    tool_calls  : List[Dict]     # list of {tool, args} to execute
    results     : List[Dict] = field(default_factory=list)
    conclusion  : str = ""


@dataclass
class BeliefUpdate:
    hypothesis_id    : str
    old_confidence   : float
    new_confidence   : float
    direction        : str       # CONFIRMED | FALSIFIED | REFINED | NEUTRAL
    reasoning        : str


# ══════════════════════════════════════════════════════════════════════════════
# 2.  Simulated Infrastructure Tools
#     These mimic real observability APIs (Datadog, PagerDuty, AWS CloudWatch).
#     Replace the return values with real API calls in production.
# ══════════════════════════════════════════════════════════════════════════════

# Ground truth for the simulation: the real root cause is a slow query
# caused by a missing DB index, discovered through the experiment chain.
INCIDENT_START = "02:14"

SIMULATED_DATA = {
    "deployments": {
        "02:00-02:20": [],
        "last": {"time": "18:45 UTC", "service": "payment-svc", "version": "v2.3.1"},
    },
    "db_metrics": {
        "connections": {
            "02:00": 22, "02:05": 24, "02:10": 31,
            "02:13": 67, "02:14": 98, "02:15": 100,
            "02:20": 100, "02:25": 100,
        },
        "max_connections": 100,
        "wait_queue": {"02:10": 0, "02:13": 12, "02:14": 47, "02:20": 89},
        "p99_latency_ms": {
            "02:00": 38, "02:05": 41, "02:10": 45,
            "02:14": 4200, "02:20": 8900,
        },
    },
    "slow_queries": [
        {
            "query"       : "SELECT * FROM orders JOIN users ON orders.user_id=users.id WHERE orders.created_at > ?",
            "count"       : 8420,
            "avg_ms"      : 4100,
            "first_seen"  : "02:13:47",
            "missing_index": "orders.created_at",
            "rows_scanned": 4200000,
            "rows_returned": 142,
        }
    ],
    "error_rate": {
        "02:00": 0.001, "02:05": 0.001, "02:10": 0.001,
        "02:13": 0.04, "02:14": 0.34, "02:20": 0.51,
    },
    "upstream_status": {
        "payment-api" : "OPERATIONAL",
        "auth-service": "OPERATIONAL",
        "email-svc"   : "OPERATIONAL",
        "cdn"         : "OPERATIONAL",
    },
    "traffic": {
        "02:00": 1200, "02:05": 1180, "02:10": 1210,
        "02:14": 1195, "02:20": 1188,
        "unit": "req/min",
    },
    "app_logs": {
        "errors": [
            {"time": "02:14:02", "level": "ERROR", "msg": "Connection pool timeout after 5000ms"},
            {"time": "02:14:03", "level": "ERROR", "msg": "Connection pool timeout after 5000ms"},
            {"time": "02:14:05", "level": "ERROR", "msg": "DB acquire timeout: pool exhausted"},
        ],
        "warnings": [
            {"time": "02:13:48", "level": "WARN", "msg": "Slow query detected: 1240ms"},
            {"time": "02:13:52", "level": "WARN", "msg": "Slow query detected: 2100ms"},
        ],
    },
    "network": {
        "packet_loss"     : "0.0%",
        "latency_ms"      : 1.2,
        "availability_zones": {"us-east-1a": "UP", "us-east-1b": "UP", "us-east-1c": "UP"},
    },
    "cpu_memory": {
        "api_servers": {"cpu_pct": 34, "mem_pct": 61, "status": "normal"},
        "db_servers" : {"cpu_pct": 89, "mem_pct": 72, "status": "elevated"},
    },
}


# ── Tool Functions (called by ADK agents) ─────────────────────────────────

def query_deployment_logs(start_time: str, end_time: str) -> dict:
    """Query deployment history within a time window."""
    return {
        "deployments_in_window" : SIMULATED_DATA["deployments"]["02:00-02:20"],
        "last_deployment"       : SIMULATED_DATA["deployments"]["last"],
        "window"                : f"{start_time} – {end_time}",
        "note"                  : "No deployments found in incident window",
    }


def query_db_metrics(metric: str, start_time: str, end_time: str) -> dict:
    """Query database performance metrics over a time range."""
    db = SIMULATED_DATA["db_metrics"]
    result = {
        "metric"         : metric,
        "window"         : f"{start_time} – {end_time}",
        "max_connections": db["max_connections"],
    }
    if metric == "connections":
        result["timeseries"] = db["connections"]
        result["wait_queue"]  = db["wait_queue"]
        result["analysis"]    = "Connection count surged from 31 to 98 between 02:10 and 02:14"
    elif metric == "query_latency" or metric == "latency":
        result["p99_latency_ms"] = db["p99_latency_ms"]
        result["analysis"]       = "P99 latency jumped 93x: 45ms → 4,200ms at 02:14"
    elif metric == "all":
        result["connections"]    = db["connections"]
        result["wait_queue"]     = db["wait_queue"]
        result["p99_latency_ms"] = db["p99_latency_ms"]
    return result


def query_slow_query_log(threshold_ms: int, start_time: str, end_time: str) -> dict:
    """Retrieve slow query log entries above a latency threshold."""
    return {
        "threshold_ms"  : threshold_ms,
        "window"        : f"{start_time} – {end_time}",
        "slow_queries"  : SIMULATED_DATA["slow_queries"],
        "total_found"   : len(SIMULATED_DATA["slow_queries"]),
        "recommendation": "Add index: CREATE INDEX CONCURRENTLY ON orders(created_at)",
    }


def check_upstream_dependencies() -> dict:
    """Check health status of all upstream service dependencies."""
    return {
        "services"       : SIMULATED_DATA["upstream_status"],
        "all_operational": all(
            v == "OPERATIONAL" for v in SIMULATED_DATA["upstream_status"].values()
        ),
        "checked_at"     : "02:18 UTC",
    }


def query_traffic_metrics(start_time: str, end_time: str) -> dict:
    """Query API request volume over a time window."""
    traffic = SIMULATED_DATA["traffic"]
    values  = [v for k, v in traffic.items() if k != "unit"]
    return {
        "timeseries"    : {k: v for k, v in traffic.items() if k != "unit"},
        "unit"          : traffic["unit"],
        "window"        : f"{start_time} – {end_time}",
        "avg_req_per_min": sum(values) / len(values),
        "max_req_per_min": max(values),
        "analysis"      : "Traffic is stable — no spike detected near incident time",
    }


def query_application_logs(level: str, start_time: str, end_time: str) -> dict:
    """Retrieve application log entries filtered by level and time."""
    logs = SIMULATED_DATA["app_logs"]
    result = {"level": level, "window": f"{start_time} – {end_time}"}
    if level.upper() in ("ERROR", "ALL"):
        result["errors"] = logs["errors"]
    if level.upper() in ("WARN", "WARNING", "ALL"):
        result["warnings"] = logs["warnings"]
    result["key_finding"] = (
        "First errors at 02:14:02 are all DB connection pool timeouts. "
        "Warnings from 02:13:48 show slow queries starting 26 seconds before errors."
    )
    return result


def query_network_health() -> dict:
    """Check network health including packet loss, latency, and AZ availability."""
    return SIMULATED_DATA["network"]


def query_cpu_memory(service: str) -> dict:
    """Query CPU and memory utilization for a given service."""
    data = SIMULATED_DATA["cpu_memory"]
    if "db" in service.lower() or "database" in service.lower():
        return {"service": service, **data["db_servers"]}
    return {"service": service, **data["api_servers"]}


def query_error_rate_timeseries(start_time: str, end_time: str) -> dict:
    """Get API error rate timeseries for the incident window."""
    return {
        "timeseries": SIMULATED_DATA["error_rate"],
        "window"    : f"{start_time} – {end_time}",
        "baseline"  : "0.1%",
        "peak"      : "51% at 02:20",
        "onset"     : "Rapid rise starting at 02:13",
    }


# Tool registry — maps string names to callable functions
TOOL_REGISTRY: Dict[str, callable] = {
    "query_deployment_logs"   : query_deployment_logs,
    "query_db_metrics"        : query_db_metrics,
    "query_slow_query_log"    : query_slow_query_log,
    "check_upstream_dependencies": check_upstream_dependencies,
    "query_traffic_metrics"   : query_traffic_metrics,
    "query_application_logs"  : query_application_logs,
    "query_network_health"    : query_network_health,
    "query_cpu_memory"        : query_cpu_memory,
    "query_error_rate_timeseries": query_error_rate_timeseries,
}


# ══════════════════════════════════════════════════════════════════════════════
# 3.  Google ADK Agent Wrapper
#     Wraps Gemini with function-calling support.
#     Each "agent" is a configured GenerativeModel + system prompt + tools.
# ══════════════════════════════════════════════════════════════════════════════

# ADK Tool schemas — Gemini function declarations
ADK_TOOLS = Tool(function_declarations=[
    FunctionDeclaration(
        name="query_deployment_logs",
        description="Query deployment history in a time window to check for recent releases.",
        parameters={
            "type": "object",
            "properties": {
                "start_time": {"type": "string", "description": "Start time e.g. '02:00'"},
                "end_time"  : {"type": "string", "description": "End time e.g. '02:20'"},
            },
            "required": ["start_time", "end_time"],
        },
    ),
    FunctionDeclaration(
        name="query_db_metrics",
        description="Query database metrics: connections, latency, wait_queue, or all.",
        parameters={
            "type": "object",
            "properties": {
                "metric"    : {"type": "string", "description": "connections | latency | all"},
                "start_time": {"type": "string"},
                "end_time"  : {"type": "string"},
            },
            "required": ["metric", "start_time", "end_time"],
        },
    ),
    FunctionDeclaration(
        name="query_slow_query_log",
        description="Retrieve slow query log entries above a given latency threshold.",
        parameters={
            "type": "object",
            "properties": {
                "threshold_ms": {"type": "integer", "description": "Minimum query duration in ms"},
                "start_time"  : {"type": "string"},
                "end_time"    : {"type": "string"},
            },
            "required": ["threshold_ms", "start_time", "end_time"],
        },
    ),
    FunctionDeclaration(
        name="check_upstream_dependencies",
        description="Check health status of all upstream service dependencies.",
        parameters={"type": "object", "properties": {}},
    ),
    FunctionDeclaration(
        name="query_traffic_metrics",
        description="Query API request volume over a time window.",
        parameters={
            "type": "object",
            "properties": {
                "start_time": {"type": "string"},
                "end_time"  : {"type": "string"},
            },
            "required": ["start_time", "end_time"],
        },
    ),
    FunctionDeclaration(
        name="query_application_logs",
        description="Retrieve application logs filtered by level (ERROR, WARN, ALL).",
        parameters={
            "type": "object",
            "properties": {
                "level"     : {"type": "string", "description": "ERROR | WARN | ALL"},
                "start_time": {"type": "string"},
                "end_time"  : {"type": "string"},
            },
            "required": ["level", "start_time", "end_time"],
        },
    ),
    FunctionDeclaration(
        name="query_network_health",
        description="Check network health: packet loss, latency, AZ availability.",
        parameters={"type": "object", "properties": {}},
    ),
    FunctionDeclaration(
        name="query_cpu_memory",
        description="Query CPU and memory utilization for a service (api-servers or db-servers).",
        parameters={
            "type": "object",
            "properties": {
                "service": {"type": "string", "description": "Service name e.g. 'db-servers'"},
            },
            "required": ["service"],
        },
    ),
    FunctionDeclaration(
        name="query_error_rate_timeseries",
        description="Get API error rate timeseries for a time window.",
        parameters={
            "type": "object",
            "properties": {
                "start_time": {"type": "string"},
                "end_time"  : {"type": "string"},
            },
            "required": ["start_time", "end_time"],
        },
    ),
])


class ADKAgent:
    """
    Wraps a Gemini GenerativeModel as a typed ADK agent.
    Handles multi-turn conversations and function calling.
    """

    def __init__(self, name: str, system_instruction: str, use_tools: bool = False):
        self.name = name
        self.model = GenerativeModel(
            model_name         = GEMINI_MODEL,
            system_instruction = system_instruction,
            tools              = [ADK_TOOLS] if use_tools else None,
        )

    def run(self, prompt: str, execute_tools: bool = False) -> Tuple[str, List[Dict]]:
        """
        Run a single-turn prompt.
        If execute_tools=True, automatically executes function calls
        and returns (text_response, tool_results).
        """
        chat         = self.model.start_chat()
        response     = chat.send_message(prompt)
        tool_results = []

        # Handle function calls if present
        if execute_tools:
            while True:
                has_fn_call = False
                fn_responses = []

                for part in response.candidates[0].content.parts:
                    if hasattr(part, "function_call") and part.function_call.name:
                        has_fn_call = True
                        fn_name = part.function_call.name
                        fn_args = dict(part.function_call.args)

                        # Execute the tool
                        tool_fn = TOOL_REGISTRY.get(fn_name)
                        if tool_fn:
                            result = tool_fn(**fn_args)
                        else:
                            result = {"error": f"Tool {fn_name} not found"}

                        tool_results.append({
                            "tool"  : fn_name,
                            "args"  : fn_args,
                            "result": result,
                        })

                        fn_responses.append({
                            "function_response": {
                                "name"    : fn_name,
                                "response": result,
                            }
                        })

                if not has_fn_call:
                    break

                # Send tool results back to model
                response = chat.send_message(fn_responses)

        # Extract text response
        text = ""
        for part in response.candidates[0].content.parts:
            if hasattr(part, "text") and part.text:
                text += part.text

        return text.strip(), tool_results

    def run_json(self, prompt: str) -> dict:
        """Run prompt and parse JSON response."""
        text, _ = self.run(prompt + "\n\nRespond with ONLY valid JSON, no markdown fences.")
        # Strip fences if present
        clean = text.strip()
        for fence in ["```json", "```"]:
            clean = clean.replace(fence, "")
        clean = clean.strip()
        try:
            return json.loads(clean)
        except json.JSONDecodeError:
            # Try to extract JSON from response
            start = clean.find("{")
            end   = clean.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(clean[start:end])
            return {}


# ══════════════════════════════════════════════════════════════════════════════
# 4.  ADK Agent Definitions
# ══════════════════════════════════════════════════════════════════════════════

def build_adk_agents() -> Dict[str, ADKAgent]:

    hypothesizer = ADKAgent(
        name="HypothesizerAgent",
        system_instruction=textwrap.dedent("""
            You are a senior Site Reliability Engineer specialising in production
            incident diagnosis. You excel at forming ranked, falsifiable hypotheses
            about infrastructure failures based on symptoms and timeline data.
            
            When forming hypotheses:
            - List ALL plausible root causes, not just the most obvious one
            - Assign initial confidence scores that sum approximately to 1.0
            - Order by likelihood given the symptoms
            - Make each hypothesis specific enough to be falsifiable
            - Think about: deployments, databases, upstream services, traffic,
              network, application bugs, infrastructure changes
        """),
    )

    experiment_designer = ADKAgent(
        name="ExperimentDesignerAgent",
        system_instruction=textwrap.dedent("""
            You are an expert in observability and SRE investigation methodology.
            You design targeted experiments to FALSIFY (not confirm) hypotheses.
            
            For each experiment you design:
            - Choose the tool call(s) that would MOST EFFICIENTLY discriminate
              between the top competing hypotheses
            - Explain what result would FALSIFY the leading hypothesis
            - Explain what result would CONFIRM it
            - Prefer tools that give the most information per experiment
            - Consider: deployment logs, DB metrics, slow query logs,
              upstream health, traffic, app logs, network, CPU/memory
        """),
        use_tools=True,
    )

    belief_updater = ADKAgent(
        name="BeliefUpdaterAgent",
        system_instruction=textwrap.dedent("""
            You are a Bayesian reasoning expert who updates hypothesis confidence
            scores based on experimental evidence. You think rigorously about
            what evidence confirms, falsifies, or is neutral toward each hypothesis.
            
            Rules for updating:
            - Evidence that directly falsifies a hypothesis → drop to 0.02-0.10
            - Strong confirming evidence → boost to 0.70-0.95
            - Weak/neutral evidence → small adjustments only
            - After each update, redistribute confidence so scores roughly sum to 1.0
              across non-falsified hypotheses
            - Explain your reasoning for EACH hypothesis update
        """),
    )

    concluder = ADKAgent(
        name="ConcluderAgent",
        system_instruction=textwrap.dedent("""
            You are a principal engineer writing incident post-mortems and runbooks.
            Given a confirmed root cause and evidence chain, you produce:
            - A clear root cause statement
            - The full evidence chain that led to the diagnosis
            - Immediate remediation steps (ranked by urgency)
            - Long-term prevention recommendations
            - Incident timeline reconstruction
            
            Be precise, actionable, and structured. Use engineering terminology.
        """),
    )

    return {
        "hypothesizer"       : hypothesizer,
        "experiment_designer": experiment_designer,
        "belief_updater"     : belief_updater,
        "concluder"          : concluder,
    }


AGENTS = build_adk_agents()


# ══════════════════════════════════════════════════════════════════════════════
# 5.  LangGraph State
# ══════════════════════════════════════════════════════════════════════════════

class HypTestState(dict):
    """
    Keys
    ----
    incident_description : str — the original incident alert
    hypotheses           : List[Hypothesis]
    experiments          : List[Experiment]
    experiment_count     : int
    top_hypothesis       : Optional[Hypothesis]
    is_concluded         : bool
    conclusion           : Optional[str]
    phase                : str
    """


def make_initial_state(incident_description: str) -> HypTestState:
    return HypTestState(
        incident_description = incident_description,
        hypotheses           = [],
        experiments          = [],
        experiment_count     = 0,
        top_hypothesis       = None,
        is_concluded         = False,
        conclusion           = None,
        phase                = "init",
    )


# ══════════════════════════════════════════════════════════════════════════════
# 6.  ADK Agent Calls
# ══════════════════════════════════════════════════════════════════════════════

def adk_hypothesize(incident: str) -> List[Hypothesis]:
    """Generate initial ranked hypotheses using the Hypothesizer ADK agent."""
    prompt = textwrap.dedent(f"""
        Production incident alert:
        {incident}

        Form 5 ranked, falsifiable hypotheses about the root cause.
        
        Return JSON:
        {{
          "hypotheses": [
            {{
              "id": "H1",
              "statement": "specific falsifiable statement",
              "confidence": 0.35,
              "reasoning": "why this is plausible given the symptoms"
            }},
            ...
          ]
        }}
        
        Requirements:
        - Confidences should sum to approximately 1.0
        - Order by descending confidence
        - Each statement must be specific enough to be testable
    """)

    data = AGENTS["hypothesizer"].run_json(prompt)
    hyps = []
    for h in data.get("hypotheses", []):
        hyps.append(Hypothesis(
            id         = h.get("id", f"H{len(hyps)+1}"),
            statement  = h.get("statement", ""),
            confidence = float(h.get("confidence", 0.2)),
        ))
    return hyps


def adk_design_and_run_experiment(
    hypotheses      : List[Hypothesis],
    experiment_count: int,
    prior_experiments: List[Experiment],
) -> Experiment:
    """
    Design an experiment targeting the top active hypothesis,
    then execute the tool calls and return results.
    Uses the ExperimentDesigner ADK agent with function calling enabled.
    """
    active_hyps = [h for h in hypotheses if h.status == "active"]
    top         = sorted(active_hyps, key=lambda h: h.confidence, reverse=True)

    hyp_summary = "\n".join(
        f"  {h.id} [{h.confidence:.2f}]: {h.statement} ({h.status})"
        for h in sorted(hypotheses, key=lambda h: h.confidence, reverse=True)
    )

    prior_summary = ""
    if prior_experiments:
        prior_summary = "\nPrior experiments run:\n" + "\n".join(
            f"  Exp {e.number}: targeted {e.target_hyp} — {e.conclusion[:100]}"
            for e in prior_experiments
        )

    prompt = textwrap.dedent(f"""
        You are designing experiment #{experiment_count + 1} for an incident diagnosis.

        Current hypothesis scoreboard:
        {hyp_summary}
        {prior_summary}

        Available tools: query_deployment_logs, query_db_metrics, query_slow_query_log,
        check_upstream_dependencies, query_traffic_metrics, query_application_logs,
        query_network_health, query_cpu_memory, query_error_rate_timeseries

        Task:
        1. Identify which hypothesis to target (focus on highest confidence active ones)
        2. Call the tool(s) that would BEST discriminate between the top hypotheses
        3. Use the incident time window: 02:00 - 02:30 UTC

        After calling tools, explain:
        - What the results mean for each hypothesis
        - What you conclude from this experiment
    """)

    text, tool_results = AGENTS["experiment_designer"].run(
        prompt, execute_tools=True
    )

    # Determine which hypothesis was targeted
    target = top[0].id if top else "H1"

    exp = Experiment(
        number      = experiment_count + 1,
        target_hyp  = target,
        rationale   = f"Targeting {target} — highest confidence active hypothesis",
        tool_calls  = [{"tool": r["tool"], "args": r["args"]} for r in tool_results],
        results     = tool_results,
        conclusion  = text,
    )
    return exp


def adk_update_beliefs(
    hypotheses  : List[Hypothesis],
    experiment  : Experiment,
) -> List[Hypothesis]:
    """
    Update hypothesis confidence scores based on experiment results.
    Uses the BeliefUpdater ADK agent.
    """
    hyp_list = json.dumps([h.to_dict() for h in hypotheses], indent=2)
    results  = json.dumps(
        [{"tool": r["tool"], "result": r["result"]} for r in experiment.results],
        indent=2
    )

    prompt = textwrap.dedent(f"""
        Update hypothesis confidence scores based on new experimental evidence.

        Current hypotheses:
        {hyp_list}

        Experiment #{experiment.number} results:
        Tool calls: {[r['tool'] for r in experiment.results]}
        
        Raw results:
        {results}

        Agent's conclusion: {experiment.conclusion[:500]}

        Return updated hypotheses as JSON:
        {{
          "updates": [
            {{
              "id": "H1",
              "new_confidence": 0.05,
              "status": "falsified",
              "direction": "FALSIFIED",
              "reasoning": "No deployment found in window → rules out deployment regression"
            }},
            {{
              "id": "H2",
              "new_confidence": 0.75,
              "status": "active",
              "direction": "CONFIRMED",
              "reasoning": "DB connections at 98/100 with 47 in queue strongly supports pool exhaustion"
            }},
            ...
          ]
        }}
        
        Status must be one of: active | confirmed | falsified
        Direction: CONFIRMED | FALSIFIED | REFINED | NEUTRAL
    """)

    data    = AGENTS["belief_updater"].run_json(prompt)
    updates = {u["id"]: u for u in data.get("updates", [])}

    for hyp in hypotheses:
        if hyp.id in updates:
            upd = updates[hyp.id]
            hyp.confidence = float(upd.get("new_confidence", hyp.confidence))
            hyp.status     = upd.get("status", hyp.status)
            direction      = upd.get("direction", "NEUTRAL")
            reasoning      = upd.get("reasoning", "")

            if direction in ("CONFIRMED", "REFINED"):
                hyp.evidence_for.append(f"Exp {experiment.number}: {reasoning[:150]}")
            elif direction == "FALSIFIED":
                hyp.evidence_against.append(f"Exp {experiment.number}: {reasoning[:150]}")

    return hypotheses


def adk_conclude(
    incident    : str,
    hypotheses  : List[Hypothesis],
    experiments : List[Experiment],
) -> str:
    """Generate final incident report using the Concluder ADK agent."""

    top     = sorted(hypotheses, key=lambda h: h.confidence, reverse=True)[0]
    hyp_str = "\n".join(
        f"  {h.id} [{h.confidence:.2f}] {h.status}: {h.statement}"
        for h in sorted(hypotheses, key=lambda h: h.confidence, reverse=True)
    )
    exp_str = "\n".join(
        f"  Exp {e.number} [{e.target_hyp}]: {e.conclusion[:200]}"
        for e in experiments
    )
    evidence_for     = "\n".join(f"  ✅ {e}" for e in top.evidence_for)
    evidence_against = "\n".join(
        f"  ✅ {e}"
        for h in hypotheses if h.status == "falsified"
        for e in h.evidence_against[:1]
    )

    prompt = textwrap.dedent(f"""
        Write a complete incident diagnosis report.

        INCIDENT: {incident}

        HYPOTHESIS SCOREBOARD:
        {hyp_str}

        CONFIRMED ROOT CAUSE: {top.statement} (confidence: {top.confidence:.0%})

        EVIDENCE FOR ROOT CAUSE:
        {evidence_for}

        FALSIFIED HYPOTHESES (evidence chain):
        {evidence_against}

        EXPERIMENTS CONDUCTED ({len(experiments)} total):
        {exp_str}

        Write a structured report with:
        1. Executive Summary (2-3 sentences)
        2. Root Cause (precise technical description)
        3. Evidence Chain (how we arrived at the diagnosis)
        4. Incident Timeline
        5. Immediate Remediation Steps (numbered, specific commands where possible)
        6. Long-term Prevention (architectural recommendations)
        7. Lessons Learned
    """)

    text, _ = AGENTS["concluder"].run(prompt)
    return text


# ══════════════════════════════════════════════════════════════════════════════
# 7.  LangGraph Node Functions
# ══════════════════════════════════════════════════════════════════════════════

def node_hypothesize(state: HypTestState) -> HypTestState:
    incident = state["incident_description"]

    print(f"\n{'═'*65}")
    print(f"  PHASE: HYPOTHESIZE")
    print(f"{'═'*65}")
    print(f"\n  🧠 Forming initial hypotheses...")

    hypotheses = adk_hypothesize(incident)

    print(f"\n  Hypothesis Scoreboard:")
    for h in sorted(hypotheses, key=lambda h: h.confidence, reverse=True):
        bar = "█" * int(h.confidence * 20)
        print(f"  {h.id} [{h.confidence:.2f}] {bar}  {h.statement}")

    return {
        **state,
        "hypotheses": hypotheses,
        "phase"     : "hypothesize",
    }


def node_design_experiment(state: HypTestState) -> HypTestState:
    hypotheses    = state["hypotheses"]
    exp_count     = state["experiment_count"]
    prior_exps    = state["experiments"]

    active = [h for h in hypotheses if h.status == "active"]
    top    = sorted(active, key=lambda h: h.confidence, reverse=True)

    print(f"\n{'─'*65}")
    print(f"  PHASE: DESIGN & RUN EXPERIMENT #{exp_count + 1}")
    print(f"{'─'*65}")
    print(f"\n  🎯 Top hypothesis: {top[0].id} [{top[0].confidence:.2f}] — {top[0].statement}")
    print(f"  🔬 Designing and executing experiment...")

    experiment = adk_design_and_run_experiment(hypotheses, exp_count, prior_exps)

    print(f"\n  Tools called:")
    for r in experiment.results:
        print(f"    ⚡ {r['tool']}({r['args']})")

    print(f"\n  Agent conclusion (preview):")
    preview = experiment.conclusion[:300].replace("\n", " ")
    print(f"    {preview}...")

    return {
        **state,
        "experiments"     : prior_exps + [experiment],
        "experiment_count": exp_count + 1,
        "phase"           : "experiment",
    }


def node_update_beliefs(state: HypTestState) -> HypTestState:
    hypotheses  = state["hypotheses"]
    experiments = state["experiments"]
    latest_exp  = experiments[-1]

    print(f"\n{'─'*65}")
    print(f"  PHASE: UPDATE BELIEFS")
    print(f"{'─'*65}")
    print(f"\n  📊 Updating confidence scores based on experiment #{latest_exp.number}...")

    updated = adk_update_beliefs(hypotheses, latest_exp)

    print(f"\n  Updated Scoreboard:")
    for h in sorted(updated, key=lambda h: h.confidence, reverse=True):
        icon = {"active": "🔵", "confirmed": "✅", "falsified": "❌"}.get(h.status, "❓")
        bar  = "█" * int(h.confidence * 20)
        print(f"  {icon} {h.id} [{h.confidence:.2f}] {bar}  {h.statement[:60]}")

    # Find current top hypothesis
    active_hyps  = [h for h in updated if h.status != "falsified"]
    top_hyp      = sorted(active_hyps, key=lambda h: h.confidence, reverse=True)[0] \
                   if active_hyps else sorted(updated, key=lambda h: h.confidence, reverse=True)[0]

    return {
        **state,
        "hypotheses"     : updated,
        "top_hypothesis" : top_hyp,
        "phase"          : "update",
    }


def node_conclude(state: HypTestState) -> HypTestState:
    incident    = state["incident_description"]
    hypotheses  = state["hypotheses"]
    experiments = state["experiments"]
    top         = state["top_hypothesis"]

    print(f"\n{'═'*65}")
    print(f"  PHASE: CONCLUDE")
    print(f"{'═'*65}")
    print(f"\n  ✅ Root cause identified: {top.statement}")
    print(f"  Confidence: {top.confidence:.0%}")
    print(f"  Experiments conducted: {len(experiments)}")
    print(f"\n  📄 Generating incident report...")

    conclusion = adk_conclude(incident, hypotheses, experiments)

    print(f"\n{'═'*65}")
    print(f"  INCIDENT DIAGNOSIS REPORT")
    print(f"{'═'*65}")
    print(conclusion)

    return {
        **state,
        "conclusion"  : conclusion,
        "is_concluded": True,
        "phase"       : "conclude",
    }


# ══════════════════════════════════════════════════════════════════════════════
# 8.  Routing Logic
# ══════════════════════════════════════════════════════════════════════════════

def route_after_update(state: HypTestState) -> str:
    hypotheses   = state["hypotheses"]
    exp_count    = state["experiment_count"]
    top          = state["top_hypothesis"]

    active_count = sum(1 for h in hypotheses if h.status == "active")

    # Conclude if:
    # 1. Top hypothesis confidence ≥ threshold AND min experiments done
    if (top and top.confidence >= CONFIDENCE_THRESHOLD
            and exp_count >= MIN_EXPERIMENTS):
        print(f"\n  🎯 Confidence threshold reached: {top.confidence:.2f} ≥ {CONFIDENCE_THRESHOLD}")
        return "conclude"

    # 2. Only one active hypothesis remains
    if active_count <= 1 and exp_count >= MIN_EXPERIMENTS:
        print(f"\n  🎯 Only {active_count} active hypothesis remaining → conclude")
        return "conclude"

    # 3. Max experiments reached
    if exp_count >= MAX_EXPERIMENTS:
        print(f"\n  ⚠️  Max experiments ({MAX_EXPERIMENTS}) reached → concluding with best hypothesis")
        return "conclude"

    # Otherwise keep experimenting
    return "design_experiment"


# ══════════════════════════════════════════════════════════════════════════════
# 9.  Build LangGraph State Machine
# ══════════════════════════════════════════════════════════════════════════════

def build_hypothesis_graph():
    """
    Hypothesis Testing State Machine:

        START → hypothesize → design_experiment → update_beliefs
                                    ↑                    │
                                    └────(loop)──────────┤
                                                         │
                                                  confidence ≥ threshold?
                                                         │
                                                        YES
                                                         │
                                                      conclude → END
    """
    builder = StateGraph(HypTestState)

    builder.add_node("hypothesize",       node_hypothesize)
    builder.add_node("design_experiment", node_design_experiment)
    builder.add_node("update_beliefs",    node_update_beliefs)
    builder.add_node("conclude",          node_conclude)

    builder.add_edge(START,               "hypothesize")
    builder.add_edge("hypothesize",       "design_experiment")
    builder.add_edge("design_experiment", "update_beliefs")

    builder.add_conditional_edges(
        "update_beliefs",
        route_after_update,
        {
            "design_experiment": "design_experiment",
            "conclude"         : "conclude",
        },
    )

    builder.add_edge("conclude", END)

    return builder.compile()


# ══════════════════════════════════════════════════════════════════════════════
# 10. Public API
# ══════════════════════════════════════════════════════════════════════════════

def diagnose_incident(incident_description: str) -> Dict[str, Any]:
    """
    Run the Hypothesis Testing agent on a production incident.

    Args:
        incident_description: Natural language incident alert

    Returns:
        Final state with diagnosis, hypothesis scoreboard, and experiment log
    """
    print("═" * 65)
    print("  Hypothesis Testing Incident Diagnosis Agent")
    print("  LangGraph + Google ADK (Gemini)")
    print("═" * 65)
    print(f"\n  Incident: {incident_description[:100]}...")
    print(f"  Confidence threshold : {CONFIDENCE_THRESHOLD:.0%}")
    print(f"  Max experiments      : {MAX_EXPERIMENTS}")

    graph         = build_hypothesis_graph()
    initial_state = make_initial_state(incident_description)
    final_state   = graph.invoke(initial_state)

    # Print summary
    print(f"\n\n{'═'*65}")
    print(f"  DIAGNOSIS SUMMARY")
    print(f"{'═'*65}")
    print(f"\n  Experiments run: {final_state['experiment_count']}")
    print(f"\n  Final Hypothesis Scoreboard:")
    for h in sorted(final_state["hypotheses"], key=lambda h: h.confidence, reverse=True):
        icon = {"active": "🔵", "confirmed": "✅", "falsified": "❌"}.get(h.status, "❓")
        print(f"  {icon} {h.id} [{h.confidence:.2f}] {h.statement}")

    return final_state


# ══════════════════════════════════════════════════════════════════════════════
# 11. Entry Point
# ══════════════════════════════════════════════════════════════════════════════

INCIDENT_ALERT = """
[P1 INCIDENT - IMMEDIATE RESPONSE REQUIRED]
Time: 02:17 UTC
Alert: API error rate spiked from baseline 0.1% to 34% starting at 02:14 UTC.
Affected: /api/v2/orders endpoint — 500 errors with message "connection timeout"
Impact: ~12,000 users unable to complete checkout. Revenue impact: ~$180k/min.
On-call: You have been paged. Identify root cause and remediation immediately.
System: Python/FastAPI backend, PostgreSQL 14, AWS us-east-1, 8 API servers.
"""

if __name__ == "__main__":
    final_state = diagnose_incident(INCIDENT_ALERT)

    # Save outputs
    if final_state.get("conclusion"):
        with open("incident_report.md", "w") as f:
            f.write(f"# Incident Diagnosis Report\n\n")
            f.write(f"**Generated:** {datetime.now().isoformat()}\n\n")
            f.write(final_state["conclusion"])
        print(f"\n  📄 Incident report saved to: incident_report.md")

    # Save experiment log
    log = []
    for exp in final_state.get("experiments", []):
        log.append({
            "experiment"     : exp.number,
            "target"         : exp.target_hyp,
            "tools_called"   : [r["tool"] for r in exp.results],
            "conclusion"     : exp.conclusion[:300],
        })

    with open("experiment_log.json", "w") as f:
        json.dump(log, f, indent=2)
    print(f"  📋 Experiment log saved to: experiment_log.json")

    # Save final hypothesis scores
    hyp_log = [h.to_dict() for h in
               sorted(final_state["hypotheses"], key=lambda h: h.confidence, reverse=True)]
    with open("hypothesis_scores.json", "w") as f:
        json.dump(hyp_log, f, indent=2)
    print(f"  📊 Hypothesis scores saved to: hypothesis_scores.json")
