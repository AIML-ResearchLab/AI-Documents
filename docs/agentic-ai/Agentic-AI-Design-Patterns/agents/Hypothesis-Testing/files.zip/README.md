# Hypothesis Testing Incident Diagnosis Agent
## LangGraph + Google ADK (Gemini)

---

## Architecture

```
START → hypothesize → design_experiment → update_beliefs
                            ↑                   │
                            └────(loop)──────────┤
                                                 │
                                       confidence ≥ 0.85?
                                                 │
                                               YES
                                                 │
                                            conclude → END
```

### Four Google ADK Agents

| Agent | Role | Key Behaviour |
|---|---|---|
| **HypothesizerAgent** | SRE with hypothesis formation expertise | Forms 5 ranked, falsifiable hypotheses with initial confidence scores |
| **ExperimentDesignerAgent** | Observability expert with tool access | Designs + executes experiments targeting the top hypothesis |
| **BeliefUpdaterAgent** | Bayesian reasoning expert | Updates all confidence scores based on evidence, marks hypotheses confirmed/falsified |
| **ConcluderAgent** | Principal engineer / post-mortem writer | Generates structured incident report with remediation steps |

---

## How Google ADK Is Used

```python
# ADK agent with Gemini function calling
agent = ADKAgent(
    name="ExperimentDesignerAgent",
    system_instruction="...",
    use_tools=True   # enables Gemini function calling
)

# Agent designs AND executes tool calls in one turn
text, tool_results = agent.run(prompt, execute_tools=True)
# tool_results = [{"tool": "query_db_metrics", "args": {...}, "result": {...}}]
```

The `ExperimentDesignerAgent` uses **Gemini native function calling** — it autonomously decides which tools to call and in what order, based on the current hypothesis state.

---

## 9 Observability Tools

| Tool | What It Returns |
|---|---|
| `query_deployment_logs` | Recent deployments in time window |
| `query_db_metrics` | DB connections, latency, wait queue |
| `query_slow_query_log` | Slow queries above threshold ms |
| `check_upstream_dependencies` | Health status of all upstream services |
| `query_traffic_metrics` | Request volume timeseries |
| `query_application_logs` | Error/warn log entries |
| `query_network_health` | Packet loss, latency, AZ status |
| `query_cpu_memory` | CPU/memory by service |
| `query_error_rate_timeseries` | API error rate over time |

Tools use realistic simulated data. Replace `_run()` bodies with real calls to Datadog, CloudWatch, PagerDuty, or your observability stack.

---

## The Hypothesis Belief Update System

After each experiment, ALL hypotheses are re-scored:

```
Initial:           After Exp 1:          After Exp 2:
H1 deploy  [0.40]  H1 deploy  [0.05] ✗   H2 db pool [0.78] ★
H2 db pool [0.30]  H2 db pool [0.45] ↑   H2a slow q [0.92] ✅
H3 upstream[0.15]  H3 upstream[0.22] ↑   H3 upstream[0.05] ✗
H4 traffic [0.10]  H4 traffic [0.18] ↑   H4 traffic [0.04] ✗
H5 network [0.05]  H5 network [0.10] ↑   H5 network [0.02] ✗
```

**Termination triggers:**
- Any hypothesis reaches confidence ≥ 0.85
- Only 1 active hypothesis remains
- Max experiments (8) reached

---

## Setup & Run

```bash
pip install -r requirements.txt
export GOOGLE_API_KEY="your-gemini-api-key"
python hypothesis_testing_agent.py
```

**Outputs:**
- `incident_report.md` — Full structured incident diagnosis
- `experiment_log.json` — Experiment-by-experiment record
- `hypothesis_scores.json` — Final confidence scores for all hypotheses

---

## Usage in Code

```python
from hypothesis_testing_agent import diagnose_incident

state = diagnose_incident("""
    [P1] API error rate 0.1% → 34% at 02:14 UTC
    Affected: /api/v2/orders — "connection timeout" errors
    Impact: ~12,000 users, $180k/min revenue loss
""")

print(state["conclusion"])     # full incident report
print(state["experiment_count"])  # how many experiments ran
```

---

## Adapting to Your Stack

### 1. Replace simulated tools with real APIs

```python
def query_db_metrics(metric: str, start_time: str, end_time: str) -> dict:
    # Replace with real Datadog / CloudWatch / Prometheus call
    response = datadog_client.query_metrics(
        query=f"avg:postgresql.connections{{*}}",
        start=parse_time(start_time),
        end=parse_time(end_time),
    )
    return response.json()
```

### 2. Tune thresholds

```python
CONFIDENCE_THRESHOLD = 0.85   # how certain before concluding
MAX_EXPERIMENTS      = 8      # cost / latency cap
MIN_EXPERIMENTS      = 2      # always run at least N experiments
```

### 3. Add custom hypothesis seeds

```python
# Pre-seed the agent with domain-specific hypotheses
DOMAIN_HINTS = """
Our system commonly fails due to:
- Redis cache eviction causing DB fallthrough storms
- ECS task memory limits causing OOM kills
- S3 throttling on high-upload endpoints
"""
```

---

## Pattern Comparison

| | ReAct | PAR | Reflexion | **Hyp. Testing** |
|---|---|---|---|---|
| Multiple competing explanations | ❌ | ❌ | ❌ | ✅ |
| Confidence scoring | ❌ | ❌ | ❌ | ✅ |
| Experiments designed to falsify | ❌ | ❌ | ❌ | ✅ |
| Learns across attempts | ❌ | ❌ | ✅ | ✅ |
| Best for | Live research | Workflows | Code debugging | **Incident diagnosis** |
