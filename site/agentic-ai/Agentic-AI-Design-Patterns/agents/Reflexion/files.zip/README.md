# Reflexion Code Debugging Agent
## LangGraph + CrewAI + Episodic Memory

---

## Architecture

```
START → generate → evaluate ──✅ PASS──→ deliver → END
            ↑          │
            │       ❌ FAIL
            │          ▼
            └───── reflect ──(MAX_ATTEMPTS)──→ exhausted → END
```

### Three CrewAI Agents

| Agent | Role | Responsibility |
|---|---|---|
| **Generator** | Expert Python Engineer | Writes code, reads episodic memory, applies past lessons |
| **Evaluator** | Code Quality Evaluator | Analyses test failures, identifies root causes |
| **Reflector** | Self-Reflection Analyst | Writes precise verbal critique stored in episodic memory |

---

## The Episodic Memory System

This is the core of Reflexion — what makes it different from simple retry:

```
Attempt 1: fails
    └── Reflector writes: "range(2,n) should be range(2,n+1), 
                           algorithm is O(n²) not Sieve"
    └── Stored in EpisodicMemory[0]

Attempt 2: (reads Memory[0]) → fixes range + algorithm → still fails
    └── Reflector writes: "Fixed range and algorithm. Still failing
                           performance test. int(n**0.5) has precision 
                           issues. Use math.isqrt(n) instead."
    └── Stored in EpisodicMemory[1]

Attempt 3: (reads Memory[0] + Memory[1]) → ✅ ALL PASS
```

Each reflection **layers on top** of prior ones. The agent's effective 
"knowledge" grows richer with each failed attempt.

---

## 13 Unit Tests

The agent must pass ALL of these:

| Test | What it checks |
|---|---|
| `test_basic_small` | sieve(10) = [2,3,5,7] |
| `test_n_equals_2` | Edge case: n=2 returns [2] |
| `test_n_equals_1` | Edge case: n=1 returns [] |
| `test_n_equals_0` | Edge case: n=0 returns [] |
| `test_negative_n` | Negative input returns [] |
| `test_n_equals_prime` | n itself is prime → included |
| `test_n_equals_composite` | n is composite → not included |
| `test_known_primes_up_to_50` | Exact list verification |
| `test_count_primes_up_to_100` | 25 primes ≤ 100 |
| `test_count_primes_up_to_1000` | 168 primes ≤ 1000 |
| `test_performance_large_n` | n=1,000,000 in under 2 seconds |
| `test_return_type` | Must return a list |
| `test_all_elements_prime` | Every element is actually prime |

---

## Setup & Run

```bash
pip install -r requirements.txt
export OPENAI_API_KEY="sk-..."
python reflexion_code_agent.py
```

**Outputs:**
- `sieve_solution.py` — the final passing solution
- `reflexion_log.json` — full attempt log with reflections

---

## Usage in Code

```python
from reflexion_code_agent import run_reflexion_agent

# Run the default Sieve task
state = run_reflexion_agent()
print(state["final_code"])
print(f"Solved in {state['attempt']} attempts")
```

## Custom Tasks

```python
from reflexion_code_agent import run_custom_task

state = run_custom_task(
    task_description="""
        Write a function `binary_search(arr, target)` that:
        1. Returns the index of target in sorted array arr
        2. Returns -1 if not found
        3. Must be O(log n) — no linear scan
    """,
    test_code='''
import unittest
class TestBinarySearch(unittest.TestCase):
    def test_found(self):
        self.assertEqual(binary_search([1,3,5,7,9], 5), 2)
    def test_not_found(self):
        self.assertEqual(binary_search([1,3,5], 4), -1)
    def test_empty(self):
        self.assertEqual(binary_search([], 1), -1)
    def test_single(self):
        self.assertEqual(binary_search([42], 42), 0)
    ''',
    function_name="binary_search"
)
```

---

## Reflexion vs Other Patterns

| | PAR | ReAct | **Reflexion** |
|---|---|---|---|
| Learns across attempts? | ❌ | ❌ | ✅ **Core feature** |
| Episodic memory? | ❌ | ❌ | ✅ |
| Self-evaluation | ✅ criteria check | ❌ | ✅ test execution |
| Recovery mechanism | PATCH / REPLAN | Continuous replanning | **Verbal reflection + memory** |
| Best for | Structured workflows | Live data research | **Trial-and-error coding tasks** |
