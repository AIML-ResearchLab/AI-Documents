"""
Reflexion Agentic Pattern — Code Debugging Agent
=================================================
Use Case    : AI-powered code generation with self-reflection & episodic memory
Orchestrator: LangGraph  — manages the Generate→Evaluate→Reflect→Retry loop
Agents      : CrewAI     — Generator, Evaluator, Reflector specialist agents
Memory      : EpisodicMemory — accumulates verbal critiques across attempts

Reflexion Loop
--------------
  GENERATE  →  EVALUATE  →  REFLECT (on failure)  →  GENERATE (with memory)
       ↑___________________________|

Key Insight: Each reflection is stored in episodic memory and injected into
             the next generation attempt — the agent learns from its own failures.

Install
-------
  pip install -r requirements.txt
  export OPENAI_API_KEY="sk-..."

Run
---
  python reflexion_code_agent.py
"""

from __future__ import annotations

import ast
import io
import json
import os
import subprocess
import sys
import textwrap
import traceback
import unittest
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

# ── LangGraph ──────────────────────────────────────────────────────────────
from langgraph.graph import END, START, StateGraph

# ── LangChain ──────────────────────────────────────────────────────────────
from langchain_openai import ChatOpenAI

# ── CrewAI ─────────────────────────────────────────────────────────────────
from crewai import Agent, Crew, Process, Task

# ══════════════════════════════════════════════════════════════════════════════
# 0.  Configuration
# ══════════════════════════════════════════════════════════════════════════════

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "sk-...")
LLM_MODEL      = "gpt-4o"
MAX_ATTEMPTS   = 5       # hard cap on reflection loops

llm = ChatOpenAI(model=LLM_MODEL, api_key=OPENAI_API_KEY, temperature=0.3)


# ══════════════════════════════════════════════════════════════════════════════
# 1.  Episodic Memory
#     The core data structure that makes Reflexion unique.
#     Stores verbal self-critiques across attempts — grows richer each loop.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class ReflectionEntry:
    """One entry in the episodic memory — verbal critique from a failed attempt."""
    attempt_num  : int
    code         : str            # the code that was generated
    test_results : str            # what the tests said
    reflection   : str            # verbal critique: WHY it failed + HOW to fix
    timestamp    : str = field(default_factory=lambda: datetime.now().isoformat())


class EpisodicMemory:
    """
    Accumulates ReflectionEntry objects across attempts.
    Provides a formatted prompt injection for the next generation attempt.
    """

    def __init__(self):
        self.entries: List[ReflectionEntry] = []

    def add(self, entry: ReflectionEntry):
        self.entries.append(entry)

    def is_empty(self) -> bool:
        return len(self.entries) == 0

    def to_prompt_context(self) -> str:
        """
        Format all past reflections into a rich context string
        to inject into the next generation prompt.
        """
        if self.is_empty():
            return ""

        lines = [
            "═" * 60,
            "EPISODIC MEMORY — Your past attempts and lessons learned:",
            "═" * 60,
        ]

        for entry in self.entries:
            lines.append(f"\n── Attempt {entry.attempt_num} ──────────────────────────")
            lines.append(f"Code written:\n```python\n{entry.code}\n```")
            lines.append(f"\nTest results:\n{entry.test_results}")
            lines.append(f"\nSelf-reflection (why it failed + how to fix):\n{entry.reflection}")

        lines.append("\n" + "═" * 60)
        lines.append("Use the above lessons to write a BETTER solution this time.")
        lines.append("═" * 60)

        return "\n".join(lines)

    def latest_reflection(self) -> Optional[str]:
        if self.entries:
            return self.entries[-1].reflection
        return None

    def summary(self) -> str:
        if self.is_empty():
            return "  (empty — first attempt)"
        return "\n".join(
            f"  Attempt {e.attempt_num}: {e.reflection[:120]}..."
            for e in self.entries
        )


# ══════════════════════════════════════════════════════════════════════════════
# 2.  Test Suite
#     Unit tests that the generated code must pass.
#     The agent can see these tests — they act as the specification.
# ══════════════════════════════════════════════════════════════════════════════

TASK_DESCRIPTION = """
Write a Python function `sieve(n: int) -> list[int]` that:
1. Returns all prime numbers up to and including n
2. Uses the Sieve of Eratosthenes algorithm (boolean array, not trial division)
3. Handles edge cases: n < 2 returns [], n = 2 returns [2]
4. Must complete for n = 1,000,000 in under 2 seconds
5. The function must be named exactly `sieve`
"""

TEST_CODE = '''
import unittest
import time

class TestSieve(unittest.TestCase):

    def test_basic_small(self):
        """Basic small primes."""
        self.assertEqual(sieve(10), [2, 3, 5, 7])

    def test_n_equals_2(self):
        """n=2 edge case — must return [2]."""
        self.assertEqual(sieve(2), [2])

    def test_n_equals_1(self):
        """n=1 — no primes below 2."""
        self.assertEqual(sieve(1), [])

    def test_n_equals_0(self):
        """n=0 — empty list."""
        self.assertEqual(sieve(0), [])

    def test_negative_n(self):
        """Negative input — empty list."""
        self.assertEqual(sieve(-5), [])

    def test_n_equals_prime(self):
        """n is itself prime — must be included."""
        self.assertEqual(sieve(13), [2, 3, 5, 7, 11, 13])

    def test_n_equals_composite(self):
        """n is composite — not included."""
        self.assertEqual(sieve(15), [2, 3, 5, 7, 11, 13])

    def test_known_primes_up_to_50(self):
        """Verify exact list up to 50."""
        expected = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
        self.assertEqual(sieve(50), expected)

    def test_count_primes_up_to_100(self):
        """There are exactly 25 primes up to 100."""
        self.assertEqual(len(sieve(100)), 25)

    def test_count_primes_up_to_1000(self):
        """There are exactly 168 primes up to 1000."""
        self.assertEqual(len(sieve(1000)), 168)

    def test_performance_large_n(self):
        """Must complete n=1,000,000 in under 2 seconds."""
        start  = time.time()
        result = sieve(1_000_000)
        elapsed = time.time() - start
        self.assertLess(elapsed, 2.0,
            f"Performance too slow: {elapsed:.2f}s (limit: 2.0s)")
        # Also verify count — there are 78498 primes up to 1M
        self.assertEqual(len(result), 78498,
            f"Wrong prime count: got {len(result)}, expected 78498")

    def test_return_type(self):
        """Must return a list."""
        self.assertIsInstance(sieve(10), list)

    def test_all_elements_prime(self):
        """Every element in result must actually be prime."""
        def is_prime(n):
            if n < 2: return False
            for i in range(2, int(n**0.5) + 1):
                if n % i == 0: return False
            return True
        result = sieve(100)
        for p in result:
            self.assertTrue(is_prime(p), f"{p} is not prime")
'''


# ══════════════════════════════════════════════════════════════════════════════
# 3.  Test Runner
#     Executes the generated code + test suite in a sandboxed namespace.
#     Returns structured results: pass/fail per test + error messages.
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TestResult:
    passed      : bool
    total_tests : int
    passed_tests: int
    failed_tests: int
    failures    : List[str]   # list of failure messages
    errors      : List[str]   # list of error messages
    output      : str         # full text output

    @property
    def pass_rate(self) -> float:
        if self.total_tests == 0:
            return 0.0
        return self.passed_tests / self.total_tests


def run_tests(generated_code: str) -> TestResult:
    """
    Execute generated_code + TEST_CODE in an isolated namespace.
    Returns a structured TestResult with per-test pass/fail info.
    """
    # ── Step 1: Syntax check ───────────────────────────────────────────────
    try:
        ast.parse(generated_code)
    except SyntaxError as e:
        return TestResult(
            passed       = False,
            total_tests  = 0,
            passed_tests = 0,
            failed_tests = 0,
            failures     = [],
            errors       = [f"SyntaxError: {e}"],
            output       = f"SyntaxError in generated code: {e}",
        )

    # ── Step 2: Execute generated code in isolated namespace ───────────────
    namespace: Dict[str, Any] = {}
    try:
        exec(compile(generated_code, "<generated>", "exec"), namespace)
    except Exception as e:
        return TestResult(
            passed       = False,
            total_tests  = 0,
            passed_tests = 0,
            failed_tests = 0,
            failures     = [],
            errors       = [f"RuntimeError during code loading: {e}"],
            output       = f"Error executing generated code:\n{traceback.format_exc()}",
        )

    # Check the required function exists
    if "sieve" not in namespace:
        return TestResult(
            passed       = False,
            total_tests  = 0,
            passed_tests = 0,
            failed_tests = 0,
            failures     = ["Function `sieve` not defined in generated code"],
            errors       = [],
            output       = "FAIL: `sieve` function not found",
        )

    # ── Step 3: Build and run test suite ──────────────────────────────────
    # Inject the generated sieve function into the test module's namespace
    test_namespace = {**namespace}

    try:
        exec(compile(TEST_CODE, "<tests>", "exec"), test_namespace)
    except Exception as e:
        return TestResult(
            passed       = False,
            total_tests  = 0,
            passed_tests = 0,
            failed_tests = 0,
            failures     = [],
            errors       = [f"Error loading test suite: {e}"],
            output       = traceback.format_exc(),
        )

    # Extract the test class
    TestSieve = test_namespace.get("TestSieve")
    if TestSieve is None:
        return TestResult(
            passed=False, total_tests=0, passed_tests=0,
            failed_tests=0, failures=[], errors=["TestSieve class not found"],
            output="Internal error: test class missing",
        )

    # Run the tests
    loader = unittest.TestLoader()
    suite  = loader.loadTestsFromTestCase(TestSieve)

    buf    = io.StringIO()
    runner = unittest.TextTestRunner(stream=buf, verbosity=2)

    result = runner.run(suite)
    output = buf.getvalue()

    failures = [f"{test}: {msg}" for test, msg in result.failures]
    errors   = [f"{test}: {msg}" for test, msg in result.errors]

    passed_count = result.testsRun - len(result.failures) - len(result.errors)
    all_passed   = len(result.failures) == 0 and len(result.errors) == 0

    return TestResult(
        passed       = all_passed,
        total_tests  = result.testsRun,
        passed_tests = passed_count,
        failed_tests = len(result.failures) + len(result.errors),
        failures     = failures,
        errors       = errors,
        output       = output,
    )


def format_test_results(result: TestResult) -> str:
    """Format TestResult into a human-readable string for the agent."""
    lines = [
        f"Test Results: {result.passed_tests}/{result.total_tests} passed "
        f"({'✅ ALL PASS' if result.passed else '❌ FAILED'})",
    ]

    if result.failures:
        lines.append("\nFailed Tests:")
        for f in result.failures:
            # Extract just the key part of the failure message
            short = f[:400].replace("\n", " | ")
            lines.append(f"  ❌ {short}")

    if result.errors:
        lines.append("\nErrors:")
        for e in result.errors:
            short = e[:400].replace("\n", " | ")
            lines.append(f"  💥 {short}")

    if result.passed:
        lines.append("\n✅ All tests passed successfully!")

    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# 4.  LangGraph State
# ══════════════════════════════════════════════════════════════════════════════

class ReflexionState(dict):
    """
    Keys
    ----
    task_description : original coding task
    test_code        : unit test suite (visible to agent)
    memory           : EpisodicMemory instance
    attempt          : current attempt number (1-indexed)
    generated_code   : latest generated code string
    test_result      : latest TestResult
    is_solved        : True when all tests pass
    final_code       : the winning code (when solved)
    attempt_log      : list of dicts logging each attempt
    """


def make_initial_state() -> ReflexionState:
    return ReflexionState(
        task_description = TASK_DESCRIPTION,
        test_code        = TEST_CODE,
        memory           = EpisodicMemory(),
        attempt          = 0,
        generated_code   = "",
        test_result      = None,
        is_solved        = False,
        final_code       = None,
        attempt_log      = [],
    )


# ══════════════════════════════════════════════════════════════════════════════
# 5.  CrewAI Agents
# ══════════════════════════════════════════════════════════════════════════════

def build_agents() -> Dict[str, Agent]:

    generator = Agent(
        role="Expert Python Engineer",
        goal=(
            "Write correct, efficient, well-tested Python code that satisfies "
            "all requirements and passes all unit tests. When given episodic "
            "memory of past failures, use those lessons explicitly to write "
            "a better solution."
        ),
        backstory=(
            "You are a senior Python engineer with deep expertise in algorithms "
            "and data structures. You write clean, efficient code and have a "
            "particular talent for fixing subtle bugs by carefully reading "
            "error messages and test failures."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    evaluator = Agent(
        role="Code Quality Evaluator",
        goal=(
            "Analyse test results objectively and determine whether the code "
            "passes all requirements. Report exactly which tests failed and why."
        ),
        backstory=(
            "You are a rigorous QA engineer who analyses test output with "
            "surgical precision. You identify root causes of failures, not "
            "just symptoms."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    reflector = Agent(
        role="Self-Reflection Analyst",
        goal=(
            "Write a precise verbal critique explaining WHY the code failed "
            "and EXACTLY what needs to change in the next attempt. "
            "Be specific — name the exact bug, line, or logic error."
        ),
        backstory=(
            "You are an expert debugger and technical writer who specialises "
            "in post-mortem analysis. You write clear, actionable debugging "
            "notes that a developer can immediately act on. You never repeat "
            "vague advice — every reflection contains a concrete fix."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    return {
        "generator": generator,
        "evaluator": evaluator,
        "reflector": reflector,
    }


AGENTS = build_agents()


# ══════════════════════════════════════════════════════════════════════════════
# 6.  CrewAI Task Runners
# ══════════════════════════════════════════════════════════════════════════════

def _run_crew(agent: Agent, description: str, expected_output: str) -> str:
    task = Task(description=description, expected_output=expected_output, agent=agent)
    crew = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=False)
    return str(crew.kickoff()).strip()


def crewai_generate(
    task_description: str,
    test_code       : str,
    memory          : EpisodicMemory,
    attempt         : int,
) -> str:
    """
    Ask the Generator agent to write code.
    Injects episodic memory context from prior failed attempts.
    """
    memory_context = memory.to_prompt_context()

    desc = textwrap.dedent(f"""
        You are writing Python code for this task:

        TASK SPECIFICATION:
        {task_description}

        UNIT TESTS (your code MUST pass ALL of these):
        ```python
        {test_code}
        ```

        {memory_context}

        INSTRUCTIONS:
        - Write ONLY the `sieve(n)` function — no imports needed unless essential
        - Do NOT include the test code
        - Do NOT include if __name__ == "__main__" blocks
        - Do NOT use markdown fences in your response
        - Return ONLY the raw Python function code, nothing else
        - Attempt number: {attempt}

        {"This is your FIRST attempt. Write your best solution." 
         if attempt == 1 else 
         f"This is attempt {attempt}. You have {attempt-1} reflection(s) in your episodic memory above. "
         "Read them carefully and apply every lesson learned."}
    """)

    raw = _run_crew(
        AGENTS["generator"], desc,
        "Raw Python function code for `sieve(n)`. No markdown, no explanation."
    )

    # Strip any accidental markdown fences
    code = raw.strip()
    for fence in ["```python", "```"]:
        if code.startswith(fence):
            code = code[len(fence):]
        if code.endswith("```"):
            code = code[:-3]

    return code.strip()


def crewai_evaluate(
    generated_code: str,
    test_result   : TestResult,
) -> str:
    """
    Ask the Evaluator agent to analyse test results and produce a structured evaluation.
    """
    desc = textwrap.dedent(f"""
        Analyse these test results for the following code:

        GENERATED CODE:
        ```python
        {generated_code}
        ```

        RAW TEST OUTPUT:
        {format_test_results(test_result)}

        Full test runner output:
        {test_result.output[:2000]}

        Provide a concise evaluation:
        1. Which tests passed?
        2. Which tests failed and what does each failure mean specifically?
        3. What is the root cause of each failure (logic error, range error, 
           performance issue, missing edge case, etc.)?
        4. Overall verdict: PASS or FAIL
    """)

    return _run_crew(
        AGENTS["evaluator"], desc,
        "Structured evaluation with root cause analysis and PASS/FAIL verdict."
    )


def crewai_reflect(
    attempt         : int,
    generated_code  : str,
    test_result     : TestResult,
    evaluation      : str,
    memory          : EpisodicMemory,
) -> str:
    """
    Ask the Reflector agent to write a verbal self-critique.
    This critique becomes the episodic memory entry for future attempts.
    """
    prior_context = memory.to_prompt_context() if not memory.is_empty() else "(No prior reflections)"

    desc = textwrap.dedent(f"""
        You are performing self-reflection after a FAILED code attempt.
        Your goal is to write a precise, actionable debugging journal entry
        that will help you write a better solution next time.

        ATTEMPT NUMBER: {attempt}

        CODE THAT FAILED:
        ```python
        {generated_code}
        ```

        TEST FAILURES:
        {format_test_results(test_result)}

        EVALUATOR'S ANALYSIS:
        {evaluation}

        PRIOR REFLECTIONS FROM MEMORY:
        {prior_context}

        Write a self-reflection journal entry covering:
        1. WHAT failed (specific test names and what they expected vs got)
        2. WHY it failed (exact bug, line number if possible, logical flaw)
        3. WHAT TO DO differently next attempt (concrete, specific changes)
        4. WHAT NOT TO REPEAT (mistakes from prior attempts, if any)

        Be extremely specific. "Fix the edge case" is bad.
        "Change range(2, n) to range(2, n+1) to include n itself" is good.
        Write as if leaving notes for yourself before your next attempt.
    """)

    return _run_crew(
        AGENTS["reflector"], desc,
        "A detailed, specific self-reflection journal entry with concrete fixes."
    )


# ══════════════════════════════════════════════════════════════════════════════
# 7.  LangGraph Node Functions
# ══════════════════════════════════════════════════════════════════════════════

def node_generate(state: ReflexionState) -> ReflexionState:
    attempt = state["attempt"] + 1
    memory  = state["memory"]

    print(f"\n{'═'*65}")
    print(f"  ATTEMPT {attempt} — GENERATE")
    print(f"{'═'*65}")
    print(f"\n  📝 Episodic Memory ({len(memory.entries)} entries):")
    print(memory.summary())
    print(f"\n  🤖 Generating code (attempt {attempt})...")

    code = crewai_generate(
        state["task_description"],
        state["test_code"],
        memory,
        attempt,
    )

    print(f"\n  Generated code:\n")
    for line in code.split("\n"):
        print(f"    {line}")

    log = state["attempt_log"] + [{
        "attempt"       : attempt,
        "code"          : code,
        "timestamp"     : datetime.now().isoformat(),
    }]

    return {
        **state,
        "attempt"        : attempt,
        "generated_code" : code,
        "attempt_log"    : log,
    }


def node_evaluate(state: ReflexionState) -> ReflexionState:
    print(f"\n{'─'*65}")
    print(f"  ATTEMPT {state['attempt']} — EVALUATE")
    print(f"{'─'*65}")
    print(f"\n  🧪 Running unit tests...")

    # Run the actual tests
    test_result = run_tests(state["generated_code"])

    print(f"\n  {format_test_results(test_result)}")

    # Get LLM evaluation of the results
    evaluation = crewai_evaluate(state["generated_code"], test_result)

    # Update the attempt log with results
    log = state["attempt_log"]
    if log:
        log[-1]["test_result"] = format_test_results(test_result)
        log[-1]["evaluation"]  = evaluation
        log[-1]["passed"]      = test_result.passed

    return {
        **state,
        "test_result" : test_result,
        "attempt_log" : log,
        "is_solved"   : test_result.passed,
        "final_code"  : state["generated_code"] if test_result.passed else None,
    }


def node_reflect(state: ReflexionState) -> ReflexionState:
    print(f"\n{'─'*65}")
    print(f"  ATTEMPT {state['attempt']} — REFLECT")
    print(f"{'─'*65}")
    print(f"\n  🔍 Writing self-reflection...")

    memory      = state["memory"]
    test_result = state["test_result"]

    # Get verbal reflection from the Reflector agent
    reflection_text = crewai_reflect(
        attempt        = state["attempt"],
        generated_code = state["generated_code"],
        test_result    = test_result,
        evaluation     = state["attempt_log"][-1].get("evaluation", ""),
        memory         = memory,
    )

    print(f"\n  💭 Reflection:\n")
    for line in textwrap.wrap(reflection_text, width=70):
        print(f"    {line}")

    # Store in episodic memory
    entry = ReflectionEntry(
        attempt_num  = state["attempt"],
        code         = state["generated_code"],
        test_results = format_test_results(test_result),
        reflection   = reflection_text,
    )
    memory.add(entry)

    # Update log
    log = state["attempt_log"]
    if log:
        log[-1]["reflection"] = reflection_text

    print(f"\n  📚 Episodic memory now has {len(memory.entries)} entries.")

    return {
        **state,
        "memory"      : memory,
        "attempt_log" : log,
    }


def node_deliver(state: ReflexionState) -> ReflexionState:
    attempt   = state["attempt"]
    test_res  = state["test_result"]
    final_code = state["final_code"]

    print(f"\n{'═'*65}")
    print(f"  ✅ SOLVED in {attempt} attempt(s)!")
    print(f"{'═'*65}")
    print(f"\n  Pass rate: {test_res.passed_tests}/{test_res.total_tests} tests")
    print(f"\n  Final Code:\n")
    for line in final_code.split("\n"):
        print(f"    {line}")

    print(f"\n  Episodic Memory used ({len(state['memory'].entries)} reflections):")
    print(state["memory"].summary())

    return state


def node_exhausted(state: ReflexionState) -> ReflexionState:
    """Called when MAX_ATTEMPTS is reached without solving."""
    attempt  = state["attempt"]
    test_res = state["test_result"]
    best     = state["generated_code"]

    print(f"\n{'═'*65}")
    print(f"  ⚠️  MAX ATTEMPTS ({MAX_ATTEMPTS}) REACHED WITHOUT FULL SOLUTION")
    print(f"{'═'*65}")
    print(f"\n  Best result: {test_res.passed_tests}/{test_res.total_tests} tests passed")
    print(f"\n  Best code generated:\n")
    for line in best.split("\n"):
        print(f"    {line}")

    print(f"\n  Accumulated reflections:")
    print(state["memory"].summary())

    return {**state, "final_code": best}


# ══════════════════════════════════════════════════════════════════════════════
# 8.  Routing Logic
# ══════════════════════════════════════════════════════════════════════════════

def route_after_evaluate(state: ReflexionState) -> str:
    if state["is_solved"]:
        return "deliver"
    if state["attempt"] >= MAX_ATTEMPTS:
        return "exhausted"
    return "reflect"


def route_after_reflect(state: ReflexionState) -> str:
    # Always loop back to generate after reflecting
    return "generate"


# ══════════════════════════════════════════════════════════════════════════════
# 9.  Build LangGraph State Machine
# ══════════════════════════════════════════════════════════════════════════════

def build_reflexion_graph():
    """
    Reflexion State Machine:

        START → generate → evaluate ──✅ PASS──→ deliver → END
                    ↑          │
                    │       ❌ FAIL
                    │          ▼
                    └───── reflect
                               │
                          (if MAX_ATTEMPTS)
                               ▼
                           exhausted → END
    """
    builder = StateGraph(ReflexionState)

    builder.add_node("generate",  node_generate)
    builder.add_node("evaluate",  node_evaluate)
    builder.add_node("reflect",   node_reflect)
    builder.add_node("deliver",   node_deliver)
    builder.add_node("exhausted", node_exhausted)

    builder.add_edge(START,       "generate")
    builder.add_edge("generate",  "evaluate")

    builder.add_conditional_edges(
        "evaluate",
        route_after_evaluate,
        {
            "deliver"  : "deliver",
            "reflect"  : "reflect",
            "exhausted": "exhausted",
        },
    )

    builder.add_conditional_edges(
        "reflect",
        route_after_reflect,
        {"generate": "generate"},
    )

    builder.add_edge("deliver",   END)
    builder.add_edge("exhausted", END)

    return builder.compile()


# ══════════════════════════════════════════════════════════════════════════════
# 10. Public API
# ══════════════════════════════════════════════════════════════════════════════

def run_reflexion_agent() -> Dict[str, Any]:
    """
    Run the Reflexion agent on the Sieve of Eratosthenes coding task.
    Returns the final state dict with solved code, attempt log, and memory.
    """
    print("═" * 65)
    print("  Reflexion Code Debugging Agent")
    print("  LangGraph + CrewAI + Episodic Memory")
    print("═" * 65)
    print(f"\n  Task: Implement Sieve of Eratosthenes")
    print(f"  Tests: {TEST_CODE.count('def test_')} unit tests must pass")
    print(f"  Max attempts: {MAX_ATTEMPTS}")
    print(f"  Model: {LLM_MODEL}")

    graph         = build_reflexion_graph()
    initial_state = make_initial_state()
    final_state   = graph.invoke(initial_state)

    # Print attempt summary
    print(f"\n\n{'═'*65}")
    print(f"  ATTEMPT SUMMARY")
    print(f"{'═'*65}")
    for log in final_state["attempt_log"]:
        status = "✅ PASS" if log.get("passed") else "❌ FAIL"
        print(f"  Attempt {log['attempt']}: {status}  |  {log.get('test_result','')[:60]}")

    return final_state


# ══════════════════════════════════════════════════════════════════════════════
# 11. Extend with Custom Tasks
# ══════════════════════════════════════════════════════════════════════════════

def run_custom_task(
    task_description: str,
    test_code       : str,
    function_name   : str = "solution",
) -> Dict[str, Any]:
    """
    Run Reflexion on any custom coding task with your own test suite.

    Args:
        task_description : Natural language description of what to implement
        test_code        : Python unittest code. The generated function will
                           be injected into the test namespace automatically.
        function_name    : Name of the function the agent must implement

    Returns:
        Final state with solved code and full attempt log

    Example:
        run_custom_task(
            task_description="Write a function `reverse_words(s)` ...",
            test_code='''
                class TestReverseWords(unittest.TestCase):
                    def test_basic(self):
                        self.assertEqual(reverse_words("hello world"), "world hello")
            ''',
            function_name="reverse_words"
        )
    """
    # Patch the module-level globals for this run
    import reflexion_code_agent as self_module
    original_task = self_module.TASK_DESCRIPTION
    original_test = self_module.TEST_CODE

    self_module.TASK_DESCRIPTION = task_description
    self_module.TEST_CODE        = test_code

    try:
        # Rebuild agents with updated context
        graph         = build_reflexion_graph()
        initial_state = make_initial_state()
        final_state   = graph.invoke(initial_state)
        return final_state
    finally:
        # Restore originals
        self_module.TASK_DESCRIPTION = original_task
        self_module.TEST_CODE        = original_test


# ══════════════════════════════════════════════════════════════════════════════
# 12. Entry Point
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    final_state = run_reflexion_agent()

    # Save the final code if solved
    if final_state.get("final_code"):
        with open("sieve_solution.py", "w") as f:
            f.write(final_state["final_code"])
        print(f"\n  💾 Final solution saved to: sieve_solution.py")

    # Save attempt log
    log_data = []
    for entry in final_state["attempt_log"]:
        log_data.append({
            "attempt"   : entry["attempt"],
            "passed"    : entry.get("passed", False),
            "reflection": entry.get("reflection", "")[:500],
        })

    with open("reflexion_log.json", "w") as f:
        json.dump(log_data, f, indent=2)
    print(f"  📋 Attempt log saved to: reflexion_log.json")
