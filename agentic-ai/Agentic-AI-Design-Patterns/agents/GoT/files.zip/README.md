# Graph-of-Thoughts Agent — CrewAI + LangGraph

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    LangGraph Orchestrator                   │
│                                                             │
│  START → generate → score → prune → aggregate → refine     │
│                  ↑___________________________|              │
│                           (loop)                           │
│                                          ↓                  │
│                                      finalize → END         │
└─────────────────────────────────────────────────────────────┘

          ↕ each node delegates to a CrewAI Agent ↕

┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  Generator   │  │  Aggregator  │  │   Refiner    │  │   Scorer     │
│  (CrewAI)    │  │  (CrewAI)    │  │  (CrewAI)    │  │  (CrewAI)    │
└──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘
```

## GoT Operations

| Operation   | LangGraph Node | CrewAI Agent  | What it does                              |
|-------------|---------------|---------------|-------------------------------------------|
| **GENERATE**  | `node_generate` | Generator   | Expands a thought into N children         |
| **SCORE**     | `node_score`    | Scorer      | Evaluates each thought (0–1 float)        |
| **PRUNE**     | `node_prune`    | —           | Drops thoughts below score threshold      |
| **AGGREGATE** | `node_aggregate`| Aggregator  | Merges multiple thoughts into one         |
| **REFINE**    | `node_refine`   | Refiner     | Iteratively improves a thought            |

## Setup

```bash
pip install -r requirements.txt
export OPENAI_API_KEY="sk-..."
python got_crewai_langgraph.py
```

## Usage

```python
from got_crewai_langgraph import solve_with_got

answer = solve_with_got(
    "What is the best way to scale a distributed database to 1B users?"
)
print(answer)
```

## Configuration (top of file)

| Constant          | Default | Description                            |
|-------------------|---------|----------------------------------------|
| `MAX_GENERATE`    | 3       | Children per GENERATE call             |
| `SCORE_THRESHOLD` | 0.6     | Thoughts below this score are pruned   |
| `MAX_REFINE_LOOPS`| 2       | Max REFINE passes per thought          |
| `MAX_GRAPH_DEPTH` | 4       | Hard limit on graph depth              |

## Data Flow Example

```
Root: "Problem: Reduce SaaS churn by 30%"
          │
   [GENERATE] 3 children
          ├── "Focus on onboarding improvements"    score=0.82 ✓
          ├── "Add loyalty reward tiers"            score=0.71 ✓
          └── "Automate win-back campaigns"         score=0.45 ✗ PRUNED
          │
   [AGGREGATE] merge top 2
          └── "Integrated onboarding + loyalty strategy" score=0.88
          │
   [REFINE] improve merged thought
          └── <detailed, structured strategy>
          │
   [FINALIZE] generate full answer
```
