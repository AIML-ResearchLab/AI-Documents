"""
Graph-of-Thoughts (GoT) Agent
==============================
Orchestrator : LangGraph (manages the GoT state machine)
Agent Framework: CrewAI  (specialist agents as graph nodes)
LLM Backend  : OpenAI GPT-4o (swap freely)

GoT Operations implemented
--------------------------
  GENERATE   – expand a thought into N children
  AGGREGATE  – merge multiple thoughts into one
  REFINE     – iteratively improve a thought
  SCORE      – evaluate thought quality (0-1)
  PRUNE      – drop low-score thoughts
"""

from __future__ import annotations

import json
import os
import uuid
from enum import Enum
from typing import Annotated, Any, Dict, List, Optional

# ── LangGraph ──────────────────────────────────────────────────────────────
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

# ── CrewAI ─────────────────────────────────────────────────────────────────
from crewai import Agent, Crew, Process, Task
from crewai_tools import tool  # for custom @tool decorators if needed

# ── LangChain (LLM plumbing shared by CrewAI) ──────────────────────────────
from langchain_openai import ChatOpenAI

# ══════════════════════════════════════════════════════════════════════════════
# 0.  Configuration
# ══════════════════════════════════════════════════════════════════════════════

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "sk-...")
LLM_MODEL      = "gpt-4o"
MAX_GENERATE   = 3        # thoughts produced per GENERATE call
SCORE_THRESHOLD = 0.6     # thoughts below this are pruned
MAX_REFINE_LOOPS = 2      # max REFINE passes per thought
MAX_GRAPH_DEPTH  = 4      # safety limit on recursion depth

llm = ChatOpenAI(model=LLM_MODEL, api_key=OPENAI_API_KEY, temperature=0.7)


# ══════════════════════════════════════════════════════════════════════════════
# 1.  GoT Data Structures
# ══════════════════════════════════════════════════════════════════════════════

class ThoughtStatus(str, Enum):
    PENDING   = "pending"
    ACTIVE    = "active"
    REFINED   = "refined"
    AGGREGATED= "aggregated"
    PRUNED    = "pruned"
    FINAL     = "final"


class ThoughtNode:
    """A single node in the Graph-of-Thoughts."""

    def __init__(
        self,
        content: str,
        parents: Optional[List[str]] = None,
        depth: int = 0,
    ):
        self.id      : str             = str(uuid.uuid4())[:8]
        self.content : str             = content
        self.parents : List[str]       = parents or []
        self.children: List[str]       = []
        self.score   : float           = 0.0
        self.status  : ThoughtStatus   = ThoughtStatus.PENDING
        self.depth   : int             = depth
        self.refine_count: int         = 0
        self.metadata: Dict[str, Any]  = {}

    def to_dict(self) -> dict:
        return {
            "id"      : self.id,
            "content" : self.content,
            "parents" : self.parents,
            "children": self.children,
            "score"   : self.score,
            "status"  : self.status.value,
            "depth"   : self.depth,
        }


class GoTGraph:
    """In-memory graph holding all ThoughtNodes."""

    def __init__(self):
        self.nodes: Dict[str, ThoughtNode] = {}

    def add(self, node: ThoughtNode) -> ThoughtNode:
        self.nodes[node.id] = node
        # register this node as a child of its parents
        for pid in node.parents:
            if pid in self.nodes:
                self.nodes[pid].children.append(node.id)
        return node

    def get(self, node_id: str) -> Optional[ThoughtNode]:
        return self.nodes.get(node_id)

    def active_nodes(self) -> List[ThoughtNode]:
        return [n for n in self.nodes.values()
                if n.status in (ThoughtStatus.PENDING, ThoughtStatus.ACTIVE,
                                ThoughtStatus.REFINED)]

    def best_nodes(self, top_k: int = 3) -> List[ThoughtNode]:
        scored = [n for n in self.nodes.values()
                  if n.status != ThoughtStatus.PRUNED]
        return sorted(scored, key=lambda n: n.score, reverse=True)[:top_k]

    def summary(self) -> str:
        lines = []
        for n in self.nodes.values():
            lines.append(
                f"[{n.id}] depth={n.depth} score={n.score:.2f} "
                f"status={n.status.value}\n  {n.content[:120]}"
            )
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# 2.  LangGraph State
# ══════════════════════════════════════════════════════════════════════════════

class GoTState(dict):
    """
    TypedDict-style state carried through the LangGraph nodes.
    Keys
    ----
    problem      : original problem string
    graph        : GoTGraph instance
    current_ids  : thought IDs being processed in this step
    operation    : last GoT operation performed
    iteration    : loop counter
    final_answer : populated when the graph concludes
    """


def make_initial_state(problem: str) -> GoTState:
    graph = GoTGraph()
    # Seed with the root thought (the problem itself)
    root = ThoughtNode(content=f"Problem: {problem}", depth=0)
    root.score  = 0.5
    root.status = ThoughtStatus.ACTIVE
    graph.add(root)

    return GoTState(
        problem      = problem,
        graph        = graph,
        current_ids  = [root.id],
        operation    = "init",
        iteration    = 0,
        final_answer = None,
    )


# ══════════════════════════════════════════════════════════════════════════════
# 3.  CrewAI Specialist Agents
# ══════════════════════════════════════════════════════════════════════════════

def build_crewai_agents() -> Dict[str, Agent]:
    """
    Four specialist agents, one per core GoT operation.
    Each agent is backed by the shared LLM.
    """

    generator = Agent(
        role="Thought Generator",
        goal=(
            "Expand a parent thought into {n} distinct, creative child thoughts "
            "that explore different angles of the problem."
        ),
        backstory=(
            "You are a divergent thinker who generates multiple hypotheses "
            "from a single premise without repeating yourself."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    aggregator = Agent(
        role="Thought Aggregator",
        goal=(
            "Synthesise several related thoughts into one coherent, "
            "higher-quality thought that captures the best of each."
        ),
        backstory=(
            "You are a synthesis expert who merges disparate ideas into "
            "a unified, stronger argument."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    refiner = Agent(
        role="Thought Refiner",
        goal=(
            "Improve the clarity, depth, and correctness of a single thought. "
            "Identify weaknesses and fix them."
        ),
        backstory=(
            "You are a critical editor who makes good ideas great through "
            "structured critique and revision."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    scorer = Agent(
        role="Thought Scorer",
        goal=(
            "Evaluate a thought and return ONLY a JSON object with keys "
            "'score' (float 0-1) and 'rationale' (one sentence)."
        ),
        backstory=(
            "You are a rigorous evaluator who judges thoughts on relevance, "
            "correctness, and potential to lead to a final answer."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    return {
        "generator" : generator,
        "aggregator": aggregator,
        "refiner"   : refiner,
        "scorer"    : scorer,
    }


AGENTS = build_crewai_agents()


# ══════════════════════════════════════════════════════════════════════════════
# 4.  CrewAI Task Helpers
#     Each helper creates a one-task Crew, runs it, and returns the result.
# ══════════════════════════════════════════════════════════════════════════════

def _run_crew(agent: Agent, task_description: str, expected_output: str) -> str:
    task = Task(
        description     = task_description,
        expected_output = expected_output,
        agent           = agent,
    )
    crew = Crew(
        agents   = [agent],
        tasks    = [task],
        process  = Process.sequential,
        verbose  = False,
    )
    result = crew.kickoff()
    # CrewAI returns a CrewOutput object; extract string
    return str(result).strip()


def crewai_generate(parent_content: str, problem: str, n: int = MAX_GENERATE) -> List[str]:
    """Ask the Generator agent to produce N child thoughts."""
    desc = (
        f"Problem: {problem}\n\n"
        f"Parent thought:\n{parent_content}\n\n"
        f"Generate exactly {n} distinct child thoughts that each explore a "
        f"different angle, sub-problem, or approach. "
        f"Return them as a JSON array of strings, e.g. [\"thought1\", \"thought2\"]."
    )
    raw = _run_crew(AGENTS["generator"], desc,
                    f"A JSON array of {n} thought strings.")
    try:
        # strip markdown fences if present
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        thoughts = json.loads(clean)
        if isinstance(thoughts, list):
            return [str(t) for t in thoughts[:n]]
    except Exception:
        pass
    # Fallback: split by newlines
    lines = [l.strip("- •*1234567890.) ").strip() for l in raw.splitlines() if l.strip()]
    return lines[:n] if lines else [raw]


def crewai_aggregate(thought_contents: List[str], problem: str) -> str:
    """Merge several thoughts into one."""
    numbered = "\n".join(f"{i+1}. {t}" for i, t in enumerate(thought_contents))
    desc = (
        f"Problem: {problem}\n\n"
        f"Thoughts to aggregate:\n{numbered}\n\n"
        "Synthesise these into ONE unified thought that captures the best "
        "insights from each. Be concise yet complete."
    )
    return _run_crew(AGENTS["aggregator"], desc,
                     "A single synthesised thought (plain text, no bullet points).")


def crewai_refine(thought_content: str, problem: str) -> str:
    """Improve a thought."""
    desc = (
        f"Problem: {problem}\n\n"
        f"Thought to refine:\n{thought_content}\n\n"
        "Identify weaknesses (vagueness, errors, missing steps) and rewrite "
        "the thought to be clearer, more correct, and more actionable."
    )
    return _run_crew(AGENTS["refiner"], desc,
                     "The improved thought (plain text).")


def crewai_score(thought_content: str, problem: str) -> tuple[float, str]:
    """Score a thought 0–1."""
    desc = (
        f"Problem: {problem}\n\n"
        f"Thought to evaluate:\n{thought_content}\n\n"
        "Return ONLY a JSON object: {\"score\": <float 0-1>, \"rationale\": \"<one sentence>\"}"
    )
    raw = _run_crew(AGENTS["scorer"], desc,
                    "JSON with 'score' and 'rationale' keys.")
    try:
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data  = json.loads(clean)
        score = float(data.get("score", 0.5))
        ratio = str(data.get("rationale", ""))
        return min(max(score, 0.0), 1.0), ratio
    except Exception:
        return 0.5, "Could not parse score."


# ══════════════════════════════════════════════════════════════════════════════
# 5.  LangGraph Node Functions
#     Each function receives + returns GoTState.
# ══════════════════════════════════════════════════════════════════════════════

def node_generate(state: GoTState) -> GoTState:
    """GENERATE: expand current active thoughts into children."""
    graph   : GoTGraph = state["graph"]
    problem : str      = state["problem"]
    new_ids : List[str] = []

    for nid in state["current_ids"]:
        node = graph.get(nid)
        if node is None or node.depth >= MAX_GRAPH_DEPTH:
            continue
        if node.status == ThoughtStatus.PRUNED:
            continue

        child_contents = crewai_generate(node.content, problem)
        for content in child_contents:
            child = ThoughtNode(content=content, parents=[nid], depth=node.depth + 1)
            child.status = ThoughtStatus.ACTIVE
            graph.add(child)
            new_ids.append(child.id)

        node.status = ThoughtStatus.ACTIVE  # parent stays active

    print(f"\n[GENERATE] Created {len(new_ids)} child thoughts.")
    return {**state, "current_ids": new_ids, "operation": "generate",
            "iteration": state["iteration"] + 1}


def node_score(state: GoTState) -> GoTState:
    """SCORE: evaluate every active thought."""
    graph   : GoTGraph = state["graph"]
    problem : str      = state["problem"]

    for nid in state["current_ids"]:
        node = graph.get(nid)
        if node is None:
            continue
        score, rationale = crewai_score(node.content, problem)
        node.score = score
        node.metadata["rationale"] = rationale
        print(f"  [SCORE] {nid}: {score:.2f} — {rationale}")

    return {**state, "operation": "score"}


def node_prune(state: GoTState) -> GoTState:
    """PRUNE: mark low-score thoughts as pruned."""
    graph     : GoTGraph = state["graph"]
    survivors : List[str] = []

    for nid in state["current_ids"]:
        node = graph.get(nid)
        if node is None:
            continue
        if node.score < SCORE_THRESHOLD:
            node.status = ThoughtStatus.PRUNED
            print(f"  [PRUNE] {nid} pruned (score={node.score:.2f})")
        else:
            survivors.append(nid)

    print(f"[PRUNE] {len(survivors)} thoughts survive.")
    return {**state, "current_ids": survivors, "operation": "prune"}


def node_aggregate(state: GoTState) -> GoTState:
    """AGGREGATE: if ≥2 survivors, merge them into one thought."""
    graph   : GoTGraph = state["graph"]
    problem : str      = state["problem"]
    ids     : List[str] = state["current_ids"]

    if len(ids) < 2:
        print("[AGGREGATE] Not enough thoughts to aggregate, skipping.")
        return {**state, "operation": "aggregate"}

    contents = [graph.get(nid).content for nid in ids if graph.get(nid)]
    merged   = crewai_aggregate(contents, problem)

    agg_node = ThoughtNode(
        content = merged,
        parents = ids,
        depth   = max(graph.get(nid).depth for nid in ids if graph.get(nid)) + 1,
    )
    agg_node.status = ThoughtStatus.AGGREGATED
    graph.add(agg_node)

    # mark parents as aggregated
    for nid in ids:
        node = graph.get(nid)
        if node:
            node.status = ThoughtStatus.AGGREGATED

    print(f"[AGGREGATE] Merged {len(ids)} thoughts → {agg_node.id}")
    return {**state, "current_ids": [agg_node.id], "operation": "aggregate"}


def node_refine(state: GoTState) -> GoTState:
    """REFINE: improve remaining active thoughts."""
    graph   : GoTGraph = state["graph"]
    problem : str      = state["problem"]

    for nid in state["current_ids"]:
        node = graph.get(nid)
        if node is None or node.refine_count >= MAX_REFINE_LOOPS:
            continue
        refined_content = crewai_refine(node.content, problem)
        node.content      = refined_content
        node.status       = ThoughtStatus.REFINED
        node.refine_count += 1
        print(f"  [REFINE] {nid} refined (pass {node.refine_count})")

    return {**state, "operation": "refine"}


def node_finalize(state: GoTState) -> GoTState:
    """
    Pick the best thought and generate a final answer using the Refiner agent
    in 'conclude' mode.
    """
    graph   : GoTGraph = state["graph"]
    problem : str      = state["problem"]

    best = graph.best_nodes(top_k=1)
    if not best:
        return {**state, "final_answer": "No valid thoughts found.", "operation": "finalize"}

    best_node = best[0]
    best_node.status = ThoughtStatus.FINAL

    # Use the refiner to turn the best thought into a final answer
    task_desc = (
        f"Problem: {problem}\n\n"
        f"Best thought developed so far:\n{best_node.content}\n\n"
        "Using this thought as your foundation, write a complete, well-structured "
        "final answer to the problem. Be thorough and actionable."
    )
    final_answer = _run_crew(
        AGENTS["refiner"], task_desc,
        "A complete, well-structured final answer."
    )

    print(f"\n[FINALIZE] Best node: {best_node.id} (score={best_node.score:.2f})")
    return {**state, "final_answer": final_answer, "operation": "finalize"}


# ══════════════════════════════════════════════════════════════════════════════
# 6.  Routing Logic
# ══════════════════════════════════════════════════════════════════════════════

def route_after_prune(state: GoTState) -> str:
    """
    Decide what to do after pruning:
     - No survivors      → finalize
     - Max depth reached → aggregate then finalize
     - Otherwise        → aggregate → refine → generate (loop)
    """
    ids   = state["current_ids"]
    graph : GoTGraph = state["graph"]

    if not ids:
        return "finalize"

    depths = [graph.get(nid).depth for nid in ids if graph.get(nid)]
    if depths and max(depths) >= MAX_GRAPH_DEPTH:
        return "aggregate"

    if state["iteration"] >= 6:          # hard cap on total iterations
        return "aggregate"

    return "aggregate"                   # always aggregate before next expand


def route_after_aggregate(state: GoTState) -> str:
    """After aggregation, always refine once then check if we should loop."""
    return "refine"


def route_after_refine(state: GoTState) -> str:
    """After refining, re-score. Decide: loop or finalize."""
    graph : GoTGraph = state["graph"]
    ids   = state["current_ids"]

    # If any thought hasn't been expanded yet and depth allows, keep looping
    for nid in ids:
        node = graph.get(nid)
        if node and not node.children and node.depth < MAX_GRAPH_DEPTH:
            return "generate"

    return "finalize"


# ══════════════════════════════════════════════════════════════════════════════
# 7.  Build the LangGraph State Machine
# ══════════════════════════════════════════════════════════════════════════════

def build_got_graph() -> StateGraph:
    """
    GoT Flow (simplified):

        START
          │
       generate
          │
        score
          │
        prune ──(no survivors)──→ finalize → END
          │
       aggregate
          │
        refine ──────────────────→ finalize → END
          │ (loop back)
       generate
    """

    builder = StateGraph(GoTState)

    # Register nodes
    builder.add_node("generate",  node_generate)
    builder.add_node("score",     node_score)
    builder.add_node("prune",     node_prune)
    builder.add_node("aggregate", node_aggregate)
    builder.add_node("refine",    node_refine)
    builder.add_node("finalize",  node_finalize)

    # Edges
    builder.add_edge(START,        "generate")
    builder.add_edge("generate",   "score")
    builder.add_edge("score",      "prune")

    builder.add_conditional_edges(
        "prune",
        route_after_prune,
        {"aggregate": "aggregate", "finalize": "finalize"},
    )

    builder.add_conditional_edges(
        "aggregate",
        route_after_aggregate,
        {"refine": "refine"},
    )

    builder.add_conditional_edges(
        "refine",
        route_after_refine,
        {"generate": "generate", "finalize": "finalize"},
    )

    builder.add_edge("finalize", END)

    return builder.compile()


# ══════════════════════════════════════════════════════════════════════════════
# 8.  Public API
# ══════════════════════════════════════════════════════════════════════════════

def solve_with_got(problem: str, verbose: bool = True) -> str:
    """
    Main entry-point.  Runs the full GoT pipeline and returns the final answer.
    """
    print("=" * 70)
    print(f"GoT Agent — Problem: {problem}")
    print("=" * 70)

    graph_app    = build_got_graph()
    initial_state = make_initial_state(problem)

    final_state: GoTState = graph_app.invoke(initial_state)

    if verbose:
        print("\n" + "=" * 70)
        print("GRAPH SUMMARY")
        print("=" * 70)
        print(final_state["graph"].summary())

    answer = final_state.get("final_answer", "No answer produced.")
    print("\n" + "=" * 70)
    print("FINAL ANSWER")
    print("=" * 70)
    print(answer)
    return answer


# ══════════════════════════════════════════════════════════════════════════════
# 9.  Demo
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    PROBLEM = (
        "Design a strategy for a mid-size SaaS company to reduce churn by 30% "
        "within 6 months without increasing headcount."
    )
    solve_with_got(PROBLEM)
