"""
Plan–Act–Reflect (PAR) Competitive Intelligence Agent
======================================================
Use Case    : Automated SaaS Competitive Intelligence Report
Orchestrator: LangGraph  — manages PLAN → ACT → REFLECT state machine
Agents      : CrewAI     — specialist agents for each phase
Tools       : Web scraping, sentiment analysis, market data, report synthesis

PAR Phases
----------
  PLAN    → Decompose goal into ordered steps with success criteria
  ACT     → Execute all planned steps, collect results
  REFLECT → Evaluate quality, decide: DELIVER / PATCH / REPLAN / EXPAND

Install
-------
  pip install -r requirements.txt
  export OPENAI_API_KEY="sk-..."

Run
---
  python par_competitive_intel.py
"""

from __future__ import annotations

import json
import os
import random
import textwrap
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

# ── LangGraph ──────────────────────────────────────────────────────────────
from langgraph.graph import END, START, StateGraph

# ── LangChain ──────────────────────────────────────────────────────────────
from langchain_openai import ChatOpenAI

# ── CrewAI ─────────────────────────────────────────────────────────────────
from crewai import Agent, Crew, Process, Task
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

# ══════════════════════════════════════════════════════════════════════════════
# 0.  Configuration
# ══════════════════════════════════════════════════════════════════════════════

OPENAI_API_KEY  = os.getenv("OPENAI_API_KEY", "sk-...")
LLM_MODEL       = "gpt-4o"
MAX_REPLAN_LOOPS = 2          # max full REPLAN cycles before forced delivery
MAX_PATCH_LOOPS  = 3          # max targeted patch attempts

llm = ChatOpenAI(model=LLM_MODEL, api_key=OPENAI_API_KEY, temperature=0.3)


# ══════════════════════════════════════════════════════════════════════════════
# 1.  Data Structures
# ══════════════════════════════════════════════════════════════════════════════

class ReflectDecision(str, Enum):
    DELIVER = "DELIVER"   # all criteria met
    PATCH   = "PATCH"     # minor gaps — re-run specific steps
    REPLAN  = "REPLAN"    # major failure — full new plan
    EXPAND  = "EXPAND"    # new info found — add steps


@dataclass
class PlanStep:
    step_id   : int
    action    : str          # tool/action name
    args      : Dict         # arguments to pass
    purpose   : str          # why this step is needed
    status    : str = "pending"   # pending | done | failed | skipped
    result    : Optional[str] = None
    error     : Optional[str] = None


@dataclass
class ExecutionPlan:
    goal            : str
    steps           : List[PlanStep]
    success_criteria: List[str]
    risk_flags      : List[str]
    created_at      : str = field(default_factory=lambda: datetime.now().isoformat())

    def to_prompt_str(self) -> str:
        lines = [f"Goal: {self.goal}\n", "Steps:"]
        for s in self.steps:
            lines.append(f"  Step {s.step_id}: [{s.action}] {s.purpose}")
        lines.append("\nSuccess Criteria:")
        for c in self.success_criteria:
            lines.append(f"  ✓ {c}")
        lines.append("\nRisk Flags:")
        for r in self.risk_flags:
            lines.append(f"  ⚠ {r}")
        return "\n".join(lines)

    def results_summary(self) -> str:
        lines = []
        for s in self.steps:
            status_icon = {"done": "✅", "failed": "❌", "pending": "⏳", "skipped": "⏭"}.get(s.status, "?")
            lines.append(f"{status_icon} Step {s.step_id} [{s.action}]: {s.status}")
            if s.result:
                lines.append(f"   Result: {s.result[:300]}")
            if s.error:
                lines.append(f"   Error:  {s.error}")
        return "\n".join(lines)


@dataclass
class ReflectionOutput:
    decision          : ReflectDecision
    criteria_met      : List[str]
    criteria_failed   : List[str]
    rationale         : str
    patch_step_ids    : List[int]   # which steps to re-run (for PATCH)
    new_steps         : List[Dict]  # extra steps (for EXPAND)


# ══════════════════════════════════════════════════════════════════════════════
# 2.  LangGraph State
# ══════════════════════════════════════════════════════════════════════════════

class PARState(dict):
    """
    Keys
    ----
    goal            : original user goal string
    competitors     : list of competitor names
    plan            : ExecutionPlan | None
    reflection      : ReflectionOutput | None
    replan_count    : int
    patch_count     : int
    final_report    : str | None
    phase           : current phase name
    """


def make_initial_state(goal: str, competitors: List[str]) -> PARState:
    return PARState(
        goal         = goal,
        competitors  = competitors,
        plan         = None,
        reflection   = None,
        replan_count = 0,
        patch_count  = 0,
        final_report = None,
        phase        = "init",
    )


# ══════════════════════════════════════════════════════════════════════════════
# 3.  Tool Implementations
#     Using realistic simulated data so the agent runs without paid APIs.
#     Replace _run() bodies with real scrapers/APIs in production.
# ══════════════════════════════════════════════════════════════════════════════

SIMULATED_PRICING = {
    "HubSpot": {
        "tiers": [
            {"name": "Free",       "price_mo": 0,    "users": "Unlimited"},
            {"name": "Starter",    "price_mo": 20,   "users": "2"},
            {"name": "Pro",        "price_mo": 890,  "users": "5"},
            {"name": "Enterprise", "price_mo": 3600, "users": "10+"},
        ],
        "free_trial": True,
        "annual_discount": "10%",
        "pricing_model": "Per seat + contact tier",
    },
    "Salesforce": {
        "tiers": [
            {"name": "Essentials", "price_mo": 25,  "users": "10 max"},
            {"name": "Pro",        "price_mo": 75,  "users": "Unlimited"},
            {"name": "Enterprise", "price_mo": 150, "users": "Unlimited"},
            {"name": "Unlimited",  "price_mo": 300, "users": "Unlimited"},
        ],
        "free_trial": True,
        "annual_discount": "20%",
        "pricing_model": "Per user / per month",
    },
    "Zoho": {
        "tiers": [
            {"name": "Standard",   "price_mo": 14, "users": "Unlimited"},
            {"name": "Pro",        "price_mo": 23, "users": "Unlimited"},
            {"name": "Enterprise", "price_mo": 40, "users": "Unlimited"},
            {"name": "Ultimate",   "price_mo": 52, "users": "Unlimited"},
        ],
        "free_trial": True,
        "annual_discount": "34%",
        "pricing_model": "Per user / per month",
    },
}

SIMULATED_FEATURES = {
    "Contact Management"       : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "Email Marketing"          : {"HubSpot": True,  "Salesforce": False, "Zoho": True},
    "Sales Pipeline"           : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "AI Lead Scoring"          : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "Custom Dashboards"        : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "Marketing Automation"     : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "Native CPQ"               : {"HubSpot": False, "Salesforce": True,  "Zoho": True},
    "Free Tier Available"      : {"HubSpot": True,  "Salesforce": False, "Zoho": False},
    "Mobile App"               : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "API Access"               : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "Workflow Automation"      : {"HubSpot": True,  "Salesforce": True,  "Zoho": True},
    "Territory Management"     : {"HubSpot": False, "Salesforce": True,  "Zoho": True},
    "Live Chat"                : {"HubSpot": True,  "Salesforce": False, "Zoho": True},
    "Social Media Integration" : {"HubSpot": True,  "Salesforce": False, "Zoho": True},
    "Advanced Analytics"       : {"HubSpot": True,  "Salesforce": True,  "Zoho": False},
    "Offline Mode"             : {"HubSpot": False, "Salesforce": True,  "Zoho": True},
}

SIMULATED_REVIEWS = {
    "HubSpot": {
        "g2_rating": 4.4, "capterra_rating": 4.5, "total_reviews": 10842,
        "sentiment_score": 0.72,
        "top_positives": ["Intuitive UI", "Excellent onboarding", "Strong marketing tools", "Great free tier"],
        "top_negatives": ["Gets expensive at scale", "Limited reporting on lower tiers", "Contact limits frustrating"],
        "nps": 42,
    },
    "Salesforce": {
        "g2_rating": 4.3, "capterra_rating": 4.4, "total_reviews": 18234,
        "sentiment_score": 0.48,
        "top_positives": ["Most feature-rich", "Massive ecosystem", "Highly customizable", "Enterprise-grade"],
        "top_negatives": ["Very complex to set up", "Requires dedicated admin", "Expensive", "Steep learning curve"],
        "nps": 28,
    },
    "Zoho": {
        "g2_rating": 4.1, "capterra_rating": 4.3, "total_reviews": 6721,
        "sentiment_score": 0.61,
        "top_positives": ["Best value for money", "Feature-rich at low price", "Good customization", "Broad suite"],
        "top_negatives": ["UI feels dated", "Support can be slow", "Documentation gaps", "Steeper learning curve"],
        "nps": 35,
    },
}

SIMULATED_MARKET_DATA = {
    "market_size_2024_usd_bn": 88.4,
    "projected_size_2029_usd_bn": 157.6,
    "cagr": "12.3%",
    "shares": {
        "Salesforce": "23.8%",
        "Microsoft Dynamics": "5.3%",
        "HubSpot": "6.1%",
        "Zoho": "3.2%",
        "Oracle": "4.1%",
        "Others": "57.5%",
    },
    "key_trends": [
        "AI-native CRM features becoming table stakes",
        "SMB segment growing fastest (18% YoY)",
        "Consolidation pressure on point solutions",
        "Vertical-specific CRM gaining traction",
    ],
}


# ── Tool: Scrape Pricing ───────────────────────────────────────────────────

class ScrapePricingInput(BaseModel):
    competitors: str = Field(..., description="Comma-separated competitor names")

class ScrapePricingTool(BaseTool):
    name: str        = "scrape_pricing"
    description: str = "Scrape and return pricing tiers for given SaaS competitors."
    args_schema: type[BaseModel] = ScrapePricingInput

    def _run(self, competitors: str) -> str:
        names   = [c.strip() for c in competitors.split(",")]
        results = {n: SIMULATED_PRICING.get(n, {"error": "not found"}) for n in names}
        return json.dumps(results, indent=2)


# ── Tool: Feature Matrix ───────────────────────────────────────────────────

class FeatureMatrixInput(BaseModel):
    competitors: str = Field(..., description="Comma-separated competitor names")

class FetchFeatureMatrixTool(BaseTool):
    name: str        = "fetch_feature_matrix"
    description: str = "Return a feature comparison matrix across competitors."
    args_schema: type[BaseModel] = FeatureMatrixInput

    def _run(self, competitors: str) -> str:
        names  = [c.strip() for c in competitors.split(",")]
        matrix = {}
        for feature, avail in SIMULATED_FEATURES.items():
            matrix[feature] = {n: avail.get(n, False) for n in names}
        return json.dumps({"feature_matrix": matrix, "competitors": names}, indent=2)


# ── Tool: Scrape Reviews ───────────────────────────────────────────────────

class ScrapeReviewsInput(BaseModel):
    competitors: str = Field(..., description="Comma-separated competitor names")
    sources     : str = Field(default="G2,Capterra", description="Review platforms")

class ScrapeReviewsTool(BaseTool):
    name: str        = "scrape_reviews"
    description: str = "Scrape customer reviews from G2 and Capterra for competitors."
    args_schema: type[BaseModel] = ScrapeReviewsInput

    def _run(self, competitors: str, sources: str = "G2,Capterra") -> str:
        names   = [c.strip() for c in competitors.split(",")]
        results = {n: SIMULATED_REVIEWS.get(n, {"error": "not found"}) for n in names}
        return json.dumps(results, indent=2)


# ── Tool: Sentiment Analysis ───────────────────────────────────────────────

class SentimentInput(BaseModel):
    review_data: str = Field(..., description="JSON string of review data from scrape_reviews")

class RunSentimentAnalysisTool(BaseTool):
    name: str        = "run_sentiment_analysis"
    description: str = "Analyse sentiment from scraped reviews and return scores per competitor."
    args_schema: type[BaseModel] = SentimentInput

    def _run(self, review_data: str) -> str:
        try:
            data    = json.loads(review_data)
            results = {}
            for comp, rev in data.items():
                if isinstance(rev, dict) and "sentiment_score" in rev:
                    score = rev["sentiment_score"]
                    label = "Very Positive" if score >= 0.7 else "Positive" if score >= 0.5 else "Mixed"
                    results[comp] = {
                        "sentiment_score"    : score,
                        "sentiment_label"    : label,
                        "top_themes_positive": rev.get("top_positives", [])[:3],
                        "top_themes_negative": rev.get("top_negatives", [])[:3],
                        "nps"                : rev.get("nps", "N/A"),
                        "review_count"       : rev.get("total_reviews", 0),
                    }
            return json.dumps(results, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})


# ── Tool: Market Share Data ────────────────────────────────────────────────

class MarketShareInput(BaseModel):
    segment: str = Field(default="CRM", description="Market segment to analyse")

class FetchMarketShareTool(BaseTool):
    name: str        = "fetch_market_share"
    description: str = "Fetch CRM market size, share by vendor, and key industry trends."
    args_schema: type[BaseModel] = MarketShareInput

    def _run(self, segment: str = "CRM") -> str:
        return json.dumps(SIMULATED_MARKET_DATA, indent=2)


# ── Tool: Synthesise Report ────────────────────────────────────────────────

class SynthesiseReportInput(BaseModel):
    pricing_data   : str = Field(..., description="JSON pricing data")
    features_data  : str = Field(..., description="JSON feature matrix")
    sentiment_data : str = Field(..., description="JSON sentiment analysis")
    market_data    : str = Field(..., description="JSON market share data")
    competitors    : str = Field(..., description="Comma-separated competitor names")
    recommendations: str = Field(default="yes", description="Include positioning recommendations?")

class SynthesiseReportTool(BaseTool):
    name: str        = "synthesise_report"
    description: str = (
        "Synthesise all collected data into a structured competitive intelligence "
        "report with positioning recommendations."
    )
    args_schema: type[BaseModel] = SynthesiseReportInput

    def _run(
        self,
        pricing_data   : str,
        features_data  : str,
        sentiment_data : str,
        market_data    : str,
        competitors    : str,
        recommendations: str = "yes",
    ) -> str:
        # Build a rich structured report from the collected data
        names = [c.strip() for c in competitors.split(",")]

        try:
            pricing   = json.loads(pricing_data)
            sentiment = json.loads(sentiment_data)
            market    = json.loads(market_data)
        except Exception:
            pricing   = {}
            sentiment = {}
            market    = {}

        sections = []

        # Header
        sections.append(f"""
# Competitive Intelligence Report
**Generated:** {datetime.now().strftime("%B %d, %Y %H:%M")}
**Competitors Analysed:** {', '.join(names)}
**Dimensions:** Pricing · Features · Customer Sentiment · Market Position
""")

        # Executive Summary
        sections.append("""
## 1. Executive Summary

This report provides a comprehensive competitive analysis across pricing strategy,
feature depth, customer sentiment, and market positioning. Key findings:

- **Salesforce** dominates market share (23.8%) but suffers from complexity complaints
- **HubSpot** leads on sentiment (0.72) and ease-of-use, strong in SMB segment  
- **Zoho** offers the best value-for-money, undercutting rivals by 60–80% on price
- The CRM market is projected to reach **$157.6B by 2029** (12.3% CAGR)
""")

        # Pricing Comparison
        pricing_rows = []
        for name in names:
            p = pricing.get(name, {})
            tiers = p.get("tiers", [])
            if tiers:
                entry_price = tiers[0].get("price_mo", "?")
                top_price   = tiers[-1].get("price_mo", "?")
                pricing_rows.append(
                    f"| {name} | ${entry_price}/mo | ${top_price}/mo | "
                    f"{p.get('pricing_model','N/A')} | {p.get('annual_discount','N/A')} |"
                )

        pricing_table = "\n".join(pricing_rows)
        sections.append(f"""
## 2. Pricing Analysis

| Vendor | Entry Price | Max Price | Model | Annual Discount |
|--------|------------|-----------|-------|-----------------|
{pricing_table}

**Key Insight:** Zoho's entry price ($14/mo) is 30% lower than HubSpot ($20/mo) and 44%
lower than Salesforce ($25/mo). At enterprise tier, the gap widens dramatically —
Salesforce Enterprise ($150/mo) costs 3.75× Zoho Enterprise ($40/mo).
""")

        # Sentiment
        sentiment_rows = []
        for name in names:
            s = sentiment.get(name, {})
            sentiment_rows.append(
                f"| {name} | {s.get('sentiment_score','N/A')} | "
                f"{s.get('sentiment_label','N/A')} | {s.get('nps','N/A')} | "
                f"{s.get('review_count', 0):,} |"
            )

        sentiment_table = "\n".join(sentiment_rows)
        sections.append(f"""
## 3. Customer Sentiment Analysis

| Vendor | Score (0-1) | Label | NPS | Reviews Analysed |
|--------|------------|-------|-----|-----------------|
{sentiment_table}

**Key Insight:** HubSpot leads sentiment by a significant margin. Salesforce's lower
score (0.48) reflects complexity and cost complaints — a persistent vulnerability.
Zoho's strong value perception (0.61) outweighs its UI/UX criticism.
""")

        # Market Position
        shares = market.get("shares", {})
        share_rows = "\n".join(
            f"| {v} | {s} |" for v, s in shares.items() if v in names or v == "Others"
        )
        trends = "\n".join(f"- {t}" for t in market.get("key_trends", []))
        sections.append(f"""
## 4. Market Positioning

**Total Addressable Market:** ${market.get('market_size_2024_usd_bn','N/A')}B (2024)  
**Projected 2029:** ${market.get('projected_size_2029_usd_bn','N/A')}B  
**CAGR:** {market.get('cagr','N/A')}

| Vendor | Market Share |
|--------|-------------|
{share_rows}

**Key Trends:**
{trends}
""")

        # Feature Highlights
        sections.append("""
## 5. Feature Differentiation

**HubSpot unique advantages:** Free tier, Email Marketing native, Live Chat, Social Media
**Salesforce unique advantages:** Native CPQ, Territory Management, Offline Mode, largest ecosystem
**Zoho unique advantages:** Best price-to-feature ratio, Live Chat, broad suite integration

**Feature parity areas:** Contact Management, Sales Pipeline, AI Lead Scoring, Mobile App,
Workflow Automation, API Access, Custom Dashboards — all three are competitive here.
""")

        # Positioning Recommendations
        if recommendations.lower() == "yes":
            sections.append("""
## 6. Strategic Positioning Recommendations

### Recommendation 1: Win Against Salesforce on Simplicity + TCO
Target Salesforce customers experiencing admin overhead and high TCO.
Lead messaging with "Enterprise power, without the enterprise complexity."
Highlight 60-day onboarding vs Salesforce's typical 6-month implementation.
ROI calculator showing TCO difference over 3 years is a high-converting asset.

### Recommendation 2: Win Against HubSpot on Depth at Scale  
HubSpot's pricing scales aggressively after 1,000 contacts. Target growth-stage
companies hitting HubSpot's ceiling. Emphasize advanced analytics, CPQ, and
territory management — features HubSpot lacks at comparable tiers.

### Recommendation 3: Win Against Zoho on Support + Ecosystem
Zoho's weaknesses are support quality and documentation. Position with
white-glove onboarding, dedicated CSMs, and a certified partner network.
Highlight SLA guarantees and response time metrics in competitive deals.

### Recommendation 4: Exploit the SMB Growth Wave
The SMB segment is growing at 18% YoY — fastest in the market. A SMB-specific
landing page, self-serve trial, and product-led growth motion can capture
customers before they consider Salesforce.
""")

        # Footer
        sections.append(f"""
---
*Report generated by PAR Competitive Intelligence Agent*  
*Data sources: Simulated G2, Capterra, vendor pricing pages, IDC market data*  
*Timestamp: {datetime.now().isoformat()}*
""")

        return "\n".join(sections)


# ══════════════════════════════════════════════════════════════════════════════
# 4.  CrewAI Agents
# ══════════════════════════════════════════════════════════════════════════════

def build_agents() -> Dict[str, Agent]:

    all_tools = [
        ScrapePricingTool(),
        FetchFeatureMatrixTool(),
        ScrapeReviewsTool(),
        RunSentimentAnalysisTool(),
        FetchMarketShareTool(),
        SynthesiseReportTool(),
    ]

    planner = Agent(
        role="Strategic Research Planner",
        goal=(
            "Decompose competitive intelligence goals into precise, ordered execution plans. "
            "Define clear success criteria and anticipate data collection risks."
        ),
        backstory=(
            "You are a senior strategy consultant with 20 years of experience designing "
            "market research frameworks for Fortune 500 companies. You excel at breaking "
            "complex analysis goals into structured, executable research plans."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    executor = Agent(
        role="Competitive Intelligence Researcher",
        goal=(
            "Execute research plans precisely — collect pricing, feature, sentiment, "
            "and market data for all specified competitors using available tools."
        ),
        backstory=(
            "You are a meticulous competitive intelligence analyst who has profiled "
            "hundreds of SaaS companies. You follow research plans exactly and collect "
            "comprehensive data using every tool available to you."
        ),
        tools=all_tools,
        llm=llm,
        verbose=False,
        allow_delegation=False,
        max_iter=15,
    )

    reflector = Agent(
        role="Quality Assurance & Research Director",
        goal=(
            "Rigorously evaluate research outputs against success criteria. "
            "Decide whether to deliver, patch specific steps, or replan from scratch. "
            "Return structured JSON decisions."
        ),
        backstory=(
            "You are a demanding research director who never lets incomplete or "
            "low-quality analysis reach clients. You evaluate work systematically "
            "against defined criteria and make clear, justified decisions."
        ),
        llm=llm,
        verbose=False,
        allow_delegation=False,
    )

    return {"planner": planner, "executor": executor, "reflector": reflector}


AGENTS = build_agents()


# ══════════════════════════════════════════════════════════════════════════════
# 5.  CrewAI Task Runners
# ══════════════════════════════════════════════════════════════════════════════

def _run_crew(agent: Agent, description: str, expected_output: str) -> str:
    task = Task(description=description, expected_output=expected_output, agent=agent)
    crew = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=False)
    return str(crew.kickoff()).strip()


def crewai_plan(goal: str, competitors: List[str]) -> ExecutionPlan:
    """Ask the Planner agent to produce a structured execution plan."""
    comp_str = ", ".join(competitors)

    desc = textwrap.dedent(f"""
        You are designing a competitive intelligence research plan.

        GOAL: {goal}
        COMPETITORS: {comp_str}
        
        Available tools:
        - scrape_pricing(competitors)         → pricing tiers per vendor
        - fetch_feature_matrix(competitors)   → feature comparison table
        - scrape_reviews(competitors)         → raw review data from G2/Capterra
        - run_sentiment_analysis(review_data) → sentiment scores from review JSON
        - fetch_market_share(segment)         → market size and share data
        - synthesise_report(pricing_data, features_data, sentiment_data, 
                            market_data, competitors, recommendations)
                                              → final structured report

        IMPORTANT: run_sentiment_analysis requires the OUTPUT of scrape_reviews 
        as its input. So scrape_reviews MUST run before run_sentiment_analysis.
        synthesise_report must be the LAST step.

        Return a JSON object with this exact structure:
        {{
          "steps": [
            {{
              "step_id": 1,
              "action": "scrape_pricing",
              "args": {{"competitors": "{comp_str}"}},
              "purpose": "why this step is needed"
            }},
            ...
          ],
          "success_criteria": [
            "All {len(competitors)} competitors have pricing data",
            "Sentiment analysis covers all competitors",
            "Report includes positioning recommendations"
          ],
          "risk_flags": [
            "Possible rate limiting on review sites",
            ...
          ]
        }}

        Return ONLY the JSON object, no markdown fences.
    """)

    raw = _run_crew(AGENTS["planner"], desc,
                    "A JSON object with steps, success_criteria, and risk_flags.")

    try:
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data  = json.loads(clean)
    except Exception:
        # Fallback: build a default plan
        data = {
            "steps": [
                {"step_id": 1, "action": "scrape_pricing",
                 "args": {"competitors": comp_str},
                 "purpose": "Get pricing tiers for all competitors"},
                {"step_id": 2, "action": "fetch_feature_matrix",
                 "args": {"competitors": comp_str},
                 "purpose": "Get feature comparison"},
                {"step_id": 3, "action": "scrape_reviews",
                 "args": {"competitors": comp_str, "sources": "G2,Capterra"},
                 "purpose": "Collect customer reviews"},
                {"step_id": 4, "action": "run_sentiment_analysis",
                 "args": {"review_data": "__FROM_STEP_3__"},
                 "purpose": "Analyse sentiment from reviews"},
                {"step_id": 5, "action": "fetch_market_share",
                 "args": {"segment": "CRM"},
                 "purpose": "Get market share and trends"},
                {"step_id": 6, "action": "synthesise_report",
                 "args": {
                     "pricing_data": "__FROM_STEP_1__",
                     "features_data": "__FROM_STEP_2__",
                     "sentiment_data": "__FROM_STEP_4__",
                     "market_data": "__FROM_STEP_5__",
                     "competitors": comp_str,
                     "recommendations": "yes",
                 },
                 "purpose": "Generate final report"},
            ],
            "success_criteria": [
                f"All {len(competitors)} competitors have pricing data",
                "Sentiment analysis completed with scores",
                "Report includes strategic positioning recommendations",
                "Market share data included",
            ],
            "risk_flags": [
                "Review scraping may be rate-limited",
                "Enterprise pricing may be gated",
            ],
        }

    steps = [
        PlanStep(
            step_id = s["step_id"],
            action  = s["action"],
            args    = s.get("args", {}),
            purpose = s.get("purpose", ""),
        )
        for s in data.get("steps", [])
    ]

    return ExecutionPlan(
        goal             = goal,
        steps            = steps,
        success_criteria = data.get("success_criteria", []),
        risk_flags       = data.get("risk_flags", []),
    )


def crewai_execute(plan: ExecutionPlan, competitors: List[str]) -> ExecutionPlan:
    """
    Execute each step in the plan using the Executor agent + tools.
    Steps are executed sequentially; results from prior steps feed into later ones.
    """
    comp_str = ", ".join(competitors)
    step_results: Dict[int, str] = {}

    tool_map = {
        "scrape_pricing"        : ScrapePricingTool(),
        "fetch_feature_matrix"  : FetchFeatureMatrixTool(),
        "scrape_reviews"        : ScrapeReviewsTool(),
        "run_sentiment_analysis": RunSentimentAnalysisTool(),
        "fetch_market_share"    : FetchMarketShareTool(),
        "synthesise_report"     : SynthesiseReportTool(),
    }

    print(f"\n{'─'*60}")
    print(f"  PHASE 2: ACT — Executing {len(plan.steps)} steps")
    print(f"{'─'*60}")

    for step in plan.steps:
        print(f"\n  ⚡ Step {step.step_id}: [{step.action}] — {step.purpose}")

        # Resolve forward references (__FROM_STEP_N__)
        resolved_args = {}
        for k, v in step.args.items():
            if isinstance(v, str) and v.startswith("__FROM_STEP_"):
                ref_id = int(v.replace("__FROM_STEP_", "").replace("__", ""))
                resolved_args[k] = step_results.get(ref_id, "")
            else:
                resolved_args[k] = v

        tool = tool_map.get(step.action)
        if not tool:
            step.status = "skipped"
            step.error  = f"Tool '{step.action}' not found"
            print(f"     ⏭  Skipped — tool not found")
            continue

        try:
            result       = tool._run(**resolved_args)
            step.result  = result
            step.status  = "done"
            step_results[step.step_id] = result
            # Show a brief preview
            preview = result[:150].replace("\n", " ")
            print(f"     ✅ Done — {preview}...")
        except Exception as e:
            step.status = "failed"
            step.error  = str(e)
            print(f"     ❌ Failed — {e}")

    return plan


def crewai_reflect(
    plan        : ExecutionPlan,
    competitors : List[str],
) -> ReflectionOutput:
    """Ask the Reflector agent to evaluate results against success criteria."""

    desc = textwrap.dedent(f"""
        You are evaluating a competitive intelligence research execution.

        ORIGINAL GOAL: {plan.goal}

        SUCCESS CRITERIA:
        {json.dumps(plan.success_criteria, indent=2)}

        EXECUTION RESULTS:
        {plan.results_summary()}

        Evaluate each success criterion as met or not met based on the results.
        
        Return ONLY a JSON object with this structure:
        {{
          "decision": "DELIVER" | "PATCH" | "REPLAN" | "EXPAND",
          "criteria_met": ["list of met criteria"],
          "criteria_failed": ["list of failed criteria"],
          "rationale": "one paragraph explaining your decision",
          "patch_step_ids": [list of step IDs to re-run if PATCH, else []],
          "new_steps": [list of new step dicts if EXPAND, else []]
        }}

        Decision rules:
        - DELIVER if all criteria are met or only trivial gaps remain
        - PATCH if 1-2 specific steps failed and can be re-run
        - REPLAN if more than half the steps failed or data is fundamentally wrong
        - EXPAND if execution revealed a new important dimension not in original plan

        Return ONLY the JSON, no markdown fences.
    """)

    raw = _run_crew(AGENTS["reflector"], desc,
                    "JSON with decision, criteria_met, criteria_failed, rationale, patch_step_ids, new_steps.")

    try:
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        data  = json.loads(clean)
    except Exception:
        # Default to DELIVER if parsing fails (results likely complete)
        data = {
            "decision"        : "DELIVER",
            "criteria_met"    : plan.success_criteria,
            "criteria_failed" : [],
            "rationale"       : "All steps completed successfully.",
            "patch_step_ids"  : [],
            "new_steps"       : [],
        }

    return ReflectionOutput(
        decision          = ReflectDecision(data.get("decision", "DELIVER")),
        criteria_met      = data.get("criteria_met", []),
        criteria_failed   = data.get("criteria_failed", []),
        rationale         = data.get("rationale", ""),
        patch_step_ids    = data.get("patch_step_ids", []),
        new_steps         = data.get("new_steps", []),
    )


# ══════════════════════════════════════════════════════════════════════════════
# 6.  LangGraph Node Functions
# ══════════════════════════════════════════════════════════════════════════════

def node_plan(state: PARState) -> PARState:
    print(f"\n{'═'*60}")
    print(f"  PHASE 1: PLAN")
    print(f"{'═'*60}")

    plan = crewai_plan(state["goal"], state["competitors"])

    print(f"\n  📋 Plan created with {len(plan.steps)} steps:")
    for s in plan.steps:
        print(f"     Step {s.step_id}: [{s.action}] — {s.purpose}")
    print(f"\n  Success Criteria:")
    for c in plan.success_criteria:
        print(f"     ✓ {c}")
    print(f"\n  Risk Flags:")
    for r in plan.risk_flags:
        print(f"     ⚠ {r}")

    return {**state, "plan": plan, "phase": "plan"}


def node_act(state: PARState) -> PARState:
    plan        = state["plan"]
    competitors = state["competitors"]

    updated_plan = crewai_execute(plan, competitors)

    print(f"\n  📊 Execution complete:")
    done    = sum(1 for s in updated_plan.steps if s.status == "done")
    failed  = sum(1 for s in updated_plan.steps if s.status == "failed")
    skipped = sum(1 for s in updated_plan.steps if s.status == "skipped")
    print(f"     ✅ Done: {done}  ❌ Failed: {failed}  ⏭ Skipped: {skipped}")

    return {**state, "plan": updated_plan, "phase": "act"}


def node_reflect(state: PARState) -> PARState:
    print(f"\n{'─'*60}")
    print(f"  PHASE 3: REFLECT")
    print(f"{'─'*60}")

    reflection = crewai_reflect(state["plan"], state["competitors"])

    print(f"\n  🔍 Reflection Decision: {reflection.decision.value}")
    print(f"  Rationale: {reflection.rationale[:200]}")

    if reflection.criteria_met:
        print(f"\n  ✅ Criteria Met:")
        for c in reflection.criteria_met:
            print(f"     • {c}")

    if reflection.criteria_failed:
        print(f"\n  ❌ Criteria Failed:")
        for c in reflection.criteria_failed:
            print(f"     • {c}")

    return {**state, "reflection": reflection, "phase": "reflect"}


def node_patch(state: PARState) -> PARState:
    """Re-run specific failed steps identified by the reflector."""
    plan       = state["plan"]
    reflection = state["reflection"]

    print(f"\n{'─'*60}")
    print(f"  PATCHING steps: {reflection.patch_step_ids}")
    print(f"{'─'*60}")

    # Reset targeted steps to pending
    for step in plan.steps:
        if step.step_id in reflection.patch_step_ids:
            step.status = "pending"
            step.result = None
            step.error  = None

    # Re-execute
    updated_plan = crewai_execute(plan, state["competitors"])

    return {
        **state,
        "plan"       : updated_plan,
        "patch_count": state["patch_count"] + 1,
        "phase"      : "patch",
    }


def node_replan(state: PARState) -> PARState:
    """Generate a completely new plan and reset execution."""
    print(f"\n{'─'*60}")
    print(f"  REPLANNING (attempt {state['replan_count'] + 1})")
    print(f"{'─'*60}")

    # Enrich goal with reflection learnings
    enriched_goal = (
        f"{state['goal']}\n\n"
        f"Previous plan failed. Reflection notes: {state['reflection'].rationale}\n"
        f"Failed criteria: {state['reflection'].criteria_failed}"
    )

    new_plan = crewai_plan(enriched_goal, state["competitors"])

    return {
        **state,
        "plan"         : new_plan,
        "reflection"   : None,
        "replan_count" : state["replan_count"] + 1,
        "phase"        : "replan",
    }


def node_expand(state: PARState) -> PARState:
    """Add new steps discovered during reflection."""
    plan       = state["plan"]
    reflection = state["reflection"]

    print(f"\n{'─'*60}")
    print(f"  EXPANDING plan with {len(reflection.new_steps)} new steps")
    print(f"{'─'*60}")

    max_id = max(s.step_id for s in plan.steps)
    for i, ns in enumerate(reflection.new_steps):
        new_step = PlanStep(
            step_id = max_id + i + 1,
            action  = ns.get("action", "unknown"),
            args    = ns.get("args", {}),
            purpose = ns.get("purpose", "Additional step from expansion"),
        )
        plan.steps.append(new_step)
        print(f"  + Step {new_step.step_id}: [{new_step.action}] — {new_step.purpose}")

    return {**state, "plan": plan, "phase": "expand"}


def node_deliver(state: PARState) -> PARState:
    """Extract the final report from the synthesise_report step result."""
    plan = state["plan"]

    # Find the synthesise_report step result
    final_report = None
    for step in reversed(plan.steps):
        if step.action == "synthesise_report" and step.result:
            final_report = step.result
            break

    if not final_report:
        # Fallback: concatenate all results
        parts = [f"# Competitive Intelligence Report\n\n*Generated: {datetime.now()}*\n"]
        for step in plan.steps:
            if step.result:
                parts.append(f"\n## {step.action}\n\n{step.result[:1000]}\n")
        final_report = "\n".join(parts)

    print(f"\n{'═'*60}")
    print(f"  ✅ DELIVERING FINAL REPORT")
    print(f"{'═'*60}")
    print(f"\n{final_report}")

    return {**state, "final_report": final_report, "phase": "deliver"}


# ══════════════════════════════════════════════════════════════════════════════
# 7.  Routing Logic
# ══════════════════════════════════════════════════════════════════════════════

def route_after_reflect(state: PARState) -> str:
    reflection   = state["reflection"]
    replan_count = state["replan_count"]
    patch_count  = state["patch_count"]

    decision = reflection.decision

    # Safety valves — force deliver if loops exceeded
    if replan_count >= MAX_REPLAN_LOOPS:
        print(f"\n  ⚠️  Max replan loops reached — forcing DELIVER")
        return "deliver"
    if patch_count >= MAX_PATCH_LOOPS:
        print(f"\n  ⚠️  Max patch loops reached — forcing DELIVER")
        return "deliver"

    route_map = {
        ReflectDecision.DELIVER: "deliver",
        ReflectDecision.PATCH  : "patch",
        ReflectDecision.REPLAN : "replan",
        ReflectDecision.EXPAND : "expand",
    }
    return route_map.get(decision, "deliver")


def route_after_patch(state: PARState) -> str:
    return "reflect"   # always reflect again after patching


def route_after_expand(state: PARState) -> str:
    return "act"       # execute the expanded steps


def route_after_replan(state: PARState) -> str:
    return "act"       # execute the new plan


# ══════════════════════════════════════════════════════════════════════════════
# 8.  Build the LangGraph State Machine
# ══════════════════════════════════════════════════════════════════════════════

def build_par_graph():
    """
    PAR State Machine:

        START → plan → act → reflect ──DELIVER──→ deliver → END
                              │  ▲
                           PATCH │
                              ▼  │
                             patch──────────────────┘
                              │
                           REPLAN
                              ▼
                            replan → act → reflect
                              │
                           EXPAND
                              ▼
                            expand → act → reflect
    """
    builder = StateGraph(PARState)

    builder.add_node("plan",    node_plan)
    builder.add_node("act",     node_act)
    builder.add_node("reflect", node_reflect)
    builder.add_node("patch",   node_patch)
    builder.add_node("replan",  node_replan)
    builder.add_node("expand",  node_expand)
    builder.add_node("deliver", node_deliver)

    builder.add_edge(START,    "plan")
    builder.add_edge("plan",   "act")
    builder.add_edge("act",    "reflect")

    builder.add_conditional_edges(
        "reflect",
        route_after_reflect,
        {
            "deliver": "deliver",
            "patch"  : "patch",
            "replan" : "replan",
            "expand" : "expand",
        },
    )

    builder.add_conditional_edges(
        "patch",
        route_after_patch,
        {"reflect": "reflect"},
    )

    builder.add_conditional_edges(
        "replan",
        route_after_replan,
        {"act": "act"},
    )

    builder.add_conditional_edges(
        "expand",
        route_after_expand,
        {"act": "act"},
    )

    builder.add_edge("deliver", END)

    return builder.compile()


# ══════════════════════════════════════════════════════════════════════════════
# 9.  Public API
# ══════════════════════════════════════════════════════════════════════════════

def run_competitive_intelligence(
    goal       : str,
    competitors: List[str],
) -> str:
    """
    Main entry-point.
    
    Args:
        goal        : Natural language goal for the analysis
        competitors : List of competitor names to analyse
    
    Returns:
        Final competitive intelligence report as a markdown string
    """
    print("═" * 60)
    print("  Plan–Act–Reflect Competitive Intelligence Agent")
    print("═" * 60)
    print(f"\n  Goal: {goal}")
    print(f"  Competitors: {', '.join(competitors)}\n")

    graph         = build_par_graph()
    initial_state = make_initial_state(goal, competitors)
    final_state   = graph.invoke(initial_state)

    return final_state.get("final_report", "No report generated.")


# ══════════════════════════════════════════════════════════════════════════════
# 10. Entry Point
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    GOAL = (
        "Generate a comprehensive competitive intelligence report comparing "
        "our SaaS CRM product against HubSpot, Salesforce, and Zoho — "
        "covering pricing strategy, feature depth, customer sentiment, "
        "and market positioning with actionable recommendations."
    )

    COMPETITORS = ["HubSpot", "Salesforce", "Zoho"]

    report = run_competitive_intelligence(GOAL, COMPETITORS)

    # Save report to file
    output_path = "competitive_intel_report.md"
    with open(output_path, "w") as f:
        f.write(report)

    print(f"\n\n  📄 Report saved to: {output_path}")
