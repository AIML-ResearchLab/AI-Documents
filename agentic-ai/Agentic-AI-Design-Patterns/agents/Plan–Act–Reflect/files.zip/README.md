# Plan–Act–Reflect (PAR) Competitive Intelligence Agent
## LangGraph + CrewAI

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    LangGraph State Machine                      │
│                                                                 │
│  START → PLAN → ACT → REFLECT ──DELIVER──→ deliver → END       │
│                          │  ▲                                   │
│                       PATCH │                                   │
│                          ▼  │                                   │
│                         patch ──────────────────────────────── │
│                          │                                      │
│                       REPLAN                                    │
│                          ▼                                      │
│                        replan → ACT → REFLECT                   │
│                          │                                      │
│                       EXPAND                                    │
│                          ▼                                      │
│                        expand → ACT → REFLECT                   │
└─────────────────────────────────────────────────────────────────┘

        ↕ each phase uses a dedicated CrewAI agent ↕

┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│   Planner    │   │   Executor   │   │  Reflector   │
│  (CrewAI)    │   │  (CrewAI)    │   │  (CrewAI)    │
│              │   │  + 6 tools   │   │              │
└──────────────┘   └──────────────┘   └──────────────┘
```

---

## Three Phases

### PLAN
The **Planner agent** decomposes the goal into ordered steps with:
- Exact tool calls + arguments for each step
- Dependency resolution (step N uses output of step M)
- Success criteria (what "done" looks like)
- Risk flags (what might go wrong)

### ACT
The **Executor agent** runs each tool step-by-step:
- Resolves `__FROM_STEP_N__` references between steps
- Collects results from all 6 data tools
- Marks each step as `done`, `failed`, or `skipped`

### REFLECT
The **Reflector agent** evaluates results against criteria and returns one of:

| Decision | Meaning | Next action |
|---|---|---|
| `DELIVER` | All criteria met | Output final report |
| `PATCH` | 1–2 specific steps failed | Re-run only those steps |
| `REPLAN` | Fundamental failure | Generate entirely new plan |
| `EXPAND` | New dimension discovered | Add steps, re-execute |

---

## 6 Research Tools

| Tool | What It Does |
|---|---|
| `scrape_pricing` | Pricing tiers per competitor |
| `fetch_feature_matrix` | Feature availability matrix |
| `scrape_reviews` | Customer reviews from G2/Capterra |
| `run_sentiment_analysis` | Sentiment scores from review data |
| `fetch_market_share` | Market size, shares, and trends |
| `synthesise_report` | Generates final markdown report |

> Tools use simulated realistic data. Replace `_run()` bodies with real
> scrapers (Playwright, BeautifulSoup) or APIs (G2, SimilarWeb, etc.)
> for production use.

---

## Setup & Run

```bash
pip install -r requirements.txt
export OPENAI_API_KEY="sk-..."
python par_competitive_intel.py
```

---

## Usage in Code

```python
from par_competitive_intel import run_competitive_intelligence

report = run_competitive_intelligence(
    goal="Analyse our CRM competitors on pricing, features, and sentiment",
    competitors=["HubSpot", "Salesforce", "Zoho"],
)
print(report)
```

---

## Output

The agent produces a structured markdown report covering:
1. Executive Summary
2. Pricing Analysis (comparison table)
3. Customer Sentiment Analysis (scores, NPS, themes)
4. Market Positioning (shares, TAM, trends)
5. Feature Differentiation (unique advantages per vendor)
6. Strategic Positioning Recommendations (4 actionable plays)

Report is also saved to `competitive_intel_report.md`.

---

## PAR vs ReAct vs GoT

| | ReAct | GoT | **PAR** |
|---|---|---|---|
| When does planning happen? | Just-in-time | None (graph-driven) | **Upfront, structured** |
| Parallel execution | ❌ | ✅ | ✅ (within ACT) |
| Explicit reflection | ❌ | ❌ | ✅ **Core phase** |
| Partial failure recovery | ✅ (reactive) | ✅ (pruning) | ✅ **(targeted PATCH)** |
| Plan is a first-class artifact | ❌ | ❌ | ✅ |
| Best for | Exploratory research | Open-ended synthesis | **Structured workflows** |
