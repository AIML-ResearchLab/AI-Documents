# ReAct Stock Research Agent — LangGraph + CrewAI

## What It Does

Answers natural-language investment questions by reasoning step-by-step
and calling live financial data tools — mimicking how a real equity analyst works.

```
Question: "Should I be concerned about NVIDIA's debt levels?"

💭 THOUGHT: I need NVDA's debt metrics and current interest rates.
⚡ ACTION : get_financials(ticker="NVDA")
👁  OBS   : {"total_debt": "$8.5B", "interest_coverage_ratio": 47.2, ...}

💭 THOUGHT: Coverage is strong but I need rate context for refinancing risk.
⚡ ACTION : get_interest_rate()
👁  OBS   : {"federal_funds_rate": "4.75%", "10yr_treasury": "4.31%"}

💭 THOUGHT: I need to check debt maturity to assess near-term refinancing exposure.
⚡ ACTION : get_debt_maturity(ticker="NVDA")
👁  OBS   : {"short_term_debt_due_1yr": "$1.25B", "long_term_debt": "$7.25B"}

✅ FINAL ANSWER: NVIDIA's debt is not a concern...
```

## Architecture

```
LangGraph State Machine
├── react_loop  ──→  CrewAI Analyst Agent
│                      ├── get_financials()        [yfinance]
│                      ├── get_debt_maturity()     [yfinance]
│                      ├── get_interest_rate()     [FRED API]
│                      ├── get_stock_price()       [yfinance]
│                      └── compare_competitors()   [yfinance]
├── check_done  (safety valve)
└── finalize    (format + print)
```

## Setup

```bash
pip install -r requirements.txt

# Required
export OPENAI_API_KEY="sk-..."

# Optional — for live Fed rate data (free key)
# https://fred.stlouisfed.org/docs/api/api_key.html
export FRED_API_KEY="your_fred_key"
```

## Run

```bash
python react_stock_agent.py
```

## Usage in Code

```python
from react_stock_agent import ask_stock_analyst

# Debt analysis
answer = ask_stock_analyst(
    "Should I be concerned about NVIDIA's debt levels given current interest rates?"
)

# Valuation comparison
answer = ask_stock_analyst(
    "Is AMD fairly valued compared to NVIDIA and Intel right now?"
)

# Risk assessment
answer = ask_stock_analyst(
    "What are the key financial risks for Apple stock over the next 6 months?"
)

print(answer)
```

## Available Tools

| Tool                  | Data Source | What It Returns                                      |
|-----------------------|-------------|------------------------------------------------------|
| `get_financials`      | yfinance    | Debt, equity, FCF, interest coverage, P/E            |
| `get_debt_maturity`   | yfinance    | Short-term vs long-term debt split                   |
| `get_interest_rate`   | FRED API    | Fed funds rate, 10yr Treasury yield                  |
| `get_stock_price`     | yfinance    | Price, 52wk range, beta, period return               |
| `compare_competitors` | yfinance    | Side-by-side P/E, D/E, margins across tickers        |

## ReAct vs Other Patterns

| Pattern | How it differs                                              |
|---------|-------------------------------------------------------------|
| CoT     | Reasons only — no real tool calls, no live data             |
| ToolUse | Acts without reasoning — no adaptive planning               |
| **ReAct**   | **Reasons before each action, updates reasoning after** |
| GoT     | Parallel thought branches — better for open-ended synthesis |
