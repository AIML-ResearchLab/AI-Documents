"""
ReAct (Reason + Act) Stock Research Agent
==========================================
Use Case   : AI-powered stock research assistant
Orchestrator: LangGraph  — manages the Thought→Action→Observation loop
Agents      : CrewAI     — specialist analyst agent with registered tools
Tools       : yfinance + FRED API for live financial & macro data

ReAct Loop
----------
  THINK  →  ACT  →  OBSERVE  →  THINK  →  ...  →  FINAL ANSWER

Install
-------
  pip install -r requirements.txt
  export OPENAI_API_KEY="sk-..."
  export FRED_API_KEY="your_fred_key"   # free at https://fred.stlouisfed.org/docs/api/api_key.html

Run
---
  python react_stock_agent.py
"""

from __future__ import annotations

import json
import os
import textwrap
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

# ── Third-party ────────────────────────────────────────────────────────────
import yfinance as yf
import requests

# ── LangGraph ──────────────────────────────────────────────────────────────
from langgraph.graph import END, START, StateGraph

# ── LangChain / OpenAI ─────────────────────────────────────────────────────
from langchain_openai import ChatOpenAI

# ── CrewAI ─────────────────────────────────────────────────────────────────
from crewai import Agent, Crew, Process, Task
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

# ══════════════════════════════════════════════════════════════════════════════
# 0.  Configuration
# ══════════════════════════════════════════════════════════════════════════════

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "sk-...")
FRED_API_KEY   = os.getenv("FRED_API_KEY", "")       # optional, graceful fallback
LLM_MODEL      = "gpt-4o"
MAX_ITERATIONS = 8    # hard cap on Thought→Action loops

llm = ChatOpenAI(model=LLM_MODEL, api_key=OPENAI_API_KEY, temperature=0.2)


# ══════════════════════════════════════════════════════════════════════════════
# 1.  Tool Definitions  (CrewAI BaseTool subclasses)
#     Each tool wraps a real data source — yfinance or FRED API.
# ══════════════════════════════════════════════════════════════════════════════

# ── 1a. Stock Financials ───────────────────────────────────────────────────

class FinancialsInput(BaseModel):
    ticker: str = Field(..., description="Stock ticker symbol e.g. NVDA, AAPL")

class GetFinancialsTool(BaseTool):
    name: str        = "get_financials"
    description: str = (
        "Fetch key financial metrics for a stock: debt, equity, free cash flow, "
        "interest coverage ratio, and P/E ratio. Input: ticker symbol."
    )
    args_schema: type[BaseModel] = FinancialsInput

    def _run(self, ticker: str) -> str:
        try:
            t    = yf.Ticker(ticker.upper())
            info = t.info
            bs   = t.balance_sheet
            cf   = t.cashflow

            total_debt = info.get("totalDebt", 0) or 0
            equity     = info.get("totalStockholderEquity") or info.get("bookValue", 1) or 1
            ebit       = info.get("ebit", 0) or 0
            int_exp    = abs(info.get("interestExpense", 1) or 1)
            fcf        = info.get("freeCashflow", 0) or 0
            pe         = info.get("trailingPE", "N/A")
            mktcap     = info.get("marketCap", 0) or 0
            revenue    = info.get("totalRevenue", 0) or 0

            coverage = round(ebit / int_exp, 1) if int_exp else "N/A"
            de_ratio  = round(total_debt / equity, 2) if equity else "N/A"

            result = {
                "ticker"                  : ticker.upper(),
                "market_cap"              : f"${mktcap/1e9:.1f}B",
                "total_debt"              : f"${total_debt/1e9:.2f}B",
                "debt_to_equity_ratio"    : de_ratio,
                "interest_coverage_ratio" : coverage,
                "free_cash_flow"          : f"${fcf/1e9:.2f}B",
                "trailing_PE"             : pe,
                "total_revenue"           : f"${revenue/1e9:.1f}B",
                "data_timestamp"          : datetime.now().strftime("%Y-%m-%d %H:%M"),
            }
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e), "ticker": ticker})


# ── 1b. Debt Maturity Schedule ─────────────────────────────────────────────

class DebtMaturityInput(BaseModel):
    ticker: str = Field(..., description="Stock ticker symbol")

class GetDebtMaturityTool(BaseTool):
    name: str        = "get_debt_maturity"
    description: str = (
        "Fetch the long-term debt maturity schedule and average coupon info "
        "for a given company. Useful for assessing refinancing risk."
    )
    args_schema: type[BaseModel] = DebtMaturityInput

    def _run(self, ticker: str) -> str:
        try:
            t    = yf.Ticker(ticker.upper())
            info = t.info

            total_debt    = info.get("totalDebt", 0) or 0
            short_term    = info.get("shortTermDebt") or info.get("currentLongTermDebt", 0) or 0
            long_term     = info.get("longTermDebt", 0) or 0

            # yfinance doesn't expose full maturity schedules publicly
            # so we derive a reasonable approximation
            result = {
                "ticker"                     : ticker.upper(),
                "total_debt"                 : f"${total_debt/1e9:.2f}B",
                "short_term_debt_due_1yr"    : f"${short_term/1e9:.2f}B",
                "long_term_debt"             : f"${long_term/1e9:.2f}B",
                "long_term_pct"              : f"{(long_term/total_debt*100):.0f}%" if total_debt else "N/A",
                "note"                       : (
                    "Short-term debt is due within 12 months. "
                    "Full maturity waterfall requires SEC 10-K filing."
                ),
                "data_timestamp"             : datetime.now().strftime("%Y-%m-%d %H:%M"),
            }
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})


# ── 1c. Current Interest Rate (FRED API) ──────────────────────────────────

class InterestRateInput(BaseModel):
    dummy: str = Field(default="none", description="No input required")

class GetInterestRateTool(BaseTool):
    name: str        = "get_interest_rate"
    description: str = (
        "Fetch the current US Federal Funds Rate and 10-year Treasury yield "
        "from FRED (Federal Reserve Economic Data). No input required."
    )
    args_schema: type[BaseModel] = InterestRateInput

    def _run(self, dummy: str = "none") -> str:
        try:
            if FRED_API_KEY:
                # Live FRED data
                def fetch_fred(series_id: str) -> Optional[float]:
                    url = (
                        f"https://api.stlouisfed.org/fred/series/observations"
                        f"?series_id={series_id}&api_key={FRED_API_KEY}"
                        f"&file_type=json&sort_order=desc&limit=1"
                    )
                    r = requests.get(url, timeout=10)
                    obs = r.json().get("observations", [])
                    return float(obs[0]["value"]) if obs else None

                fed_rate   = fetch_fred("FEDFUNDS")
                treasury10 = fetch_fred("DGS10")
            else:
                # Fallback: representative values (update manually if needed)
                fed_rate   = 4.75
                treasury10 = 4.31

            result = {
                "federal_funds_rate"  : f"{fed_rate:.2f}%" if fed_rate else "N/A",
                "10yr_treasury_yield" : f"{treasury10:.2f}%" if treasury10 else "N/A",
                "rate_environment"    : "elevated" if (fed_rate or 0) > 4 else "moderate",
                "source"              : "FRED (Federal Reserve)" if FRED_API_KEY else "Fallback static data",
                "data_timestamp"      : datetime.now().strftime("%Y-%m-%d %H:%M"),
                "note"                : (
                    "Set FRED_API_KEY env var for live data. "
                    "Free key at https://fred.stlouisfed.org/docs/api/api_key.html"
                ) if not FRED_API_KEY else "",
            }
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})


# ── 1d. Stock Price & Trend ────────────────────────────────────────────────

class PriceInput(BaseModel):
    ticker: str = Field(..., description="Stock ticker symbol")
    period: str = Field(default="3mo", description="Period: 1mo, 3mo, 6mo, 1y")

class GetStockPriceTool(BaseTool):
    name: str        = "get_stock_price"
    description: str = (
        "Fetch current stock price, 52-week high/low, and recent price trend "
        "for a given ticker. Period options: 1mo, 3mo, 6mo, 1y."
    )
    args_schema: type[BaseModel] = PriceInput

    def _run(self, ticker: str, period: str = "3mo") -> str:
        try:
            t    = yf.Ticker(ticker.upper())
            info = t.info
            hist = t.history(period=period)

            current    = info.get("currentPrice") or info.get("regularMarketPrice", 0)
            week52_hi  = info.get("fiftyTwoWeekHigh", 0)
            week52_lo  = info.get("fiftyTwoWeekLow", 0)
            avg_vol    = info.get("averageVolume", 0)
            beta       = info.get("beta", "N/A")

            period_ret = "N/A"
            if not hist.empty:
                start_p = hist["Close"].iloc[0]
                end_p   = hist["Close"].iloc[-1]
                period_ret = f"{((end_p - start_p) / start_p * 100):.1f}%"

            result = {
                "ticker"             : ticker.upper(),
                "current_price"      : f"${current:.2f}",
                "52wk_high"          : f"${week52_hi:.2f}",
                "52wk_low"           : f"${week52_lo:.2f}",
                f"return_{period}"   : period_ret,
                "beta"               : beta,
                "avg_daily_volume"   : f"{avg_vol:,}",
                "data_timestamp"     : datetime.now().strftime("%Y-%m-%d %H:%M"),
            }
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})


# ── 1e. Competitor Comparison ──────────────────────────────────────────────

class CompetitorInput(BaseModel):
    tickers: str = Field(
        ...,
        description="Comma-separated list of ticker symbols e.g. 'NVDA,AMD,INTC'"
    )

class CompareCompetitorsTool(BaseTool):
    name: str        = "compare_competitors"
    description: str = (
        "Compare key metrics (P/E, debt-to-equity, market cap, revenue) "
        "across multiple competitors. Input: comma-separated ticker symbols."
    )
    args_schema: type[BaseModel] = CompetitorInput

    def _run(self, tickers: str) -> str:
        try:
            results = []
            for ticker in [t.strip().upper() for t in tickers.split(",")]:
                info = yf.Ticker(ticker).info
                results.append({
                    "ticker"         : ticker,
                    "market_cap"     : f"${(info.get('marketCap',0) or 0)/1e9:.1f}B",
                    "trailing_PE"    : info.get("trailingPE", "N/A"),
                    "debt_to_equity" : info.get("debtToEquity", "N/A"),
                    "profit_margin"  : f"{(info.get('profitMargins',0) or 0)*100:.1f}%",
                    "revenue_growth" : f"{(info.get('revenueGrowth',0) or 0)*100:.1f}%",
                })
            return json.dumps(results, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})


# ══════════════════════════════════════════════════════════════════════════════
# 2.  ReAct State  (passed through LangGraph)
# ══════════════════════════════════════════════════════════════════════════════

class ReActStep:
    """Represents one Thought→Action→Observation triple."""
    def __init__(self, thought: str, action: str, observation: str, iteration: int):
        self.thought     = thought
        self.action      = action
        self.observation = observation
        self.iteration   = iteration

    def __str__(self) -> str:
        return (
            f"\n{'─'*60}\n"
            f"Iteration {self.iteration}\n"
            f"{'─'*60}\n"
            f"💭 THOUGHT:\n{textwrap.indent(self.thought, '  ')}\n\n"
            f"⚡ ACTION:  {self.action}\n\n"
            f"👁  OBSERVATION:\n{textwrap.indent(self.observation[:600], '  ')}\n"
        )


class ReActState(dict):
    """
    Keys
    ----
    question     : original user question
    steps        : List[ReActStep] — full trace
    iteration    : current loop count
    is_done      : True when agent decides to stop
    final_answer : the agent's conclusion
    """


def make_initial_state(question: str) -> ReActState:
    return ReActState(
        question     = question,
        steps        = [],
        iteration    = 0,
        is_done      = False,
        final_answer = None,
    )


# ══════════════════════════════════════════════════════════════════════════════
# 3.  CrewAI Agent — The Stock Research Analyst
# ══════════════════════════════════════════════════════════════════════════════

def build_analyst_agent() -> Agent:
    tools = [
        GetFinancialsTool(),
        GetDebtMaturityTool(),
        GetInterestRateTool(),
        GetStockPriceTool(),
        CompareCompetitorsTool(),
    ]

    return Agent(
        role="Senior Equity Research Analyst",
        goal=(
            "Answer investor questions about stocks by reasoning step-by-step "
            "and using financial data tools to fetch live information. "
            "Always explain your reasoning before taking an action, and update "
            "your reasoning based on what you observe."
        ),
        backstory=(
            "You are a CFA-certified equity analyst at a top-tier investment bank "
            "with 15 years of experience covering technology and semiconductor stocks. "
            "You are rigorous, data-driven, and skilled at synthesising macro trends "
            "with company-specific fundamentals to give clear, actionable insights."
        ),
        tools=tools,
        llm=llm,
        verbose=True,
        allow_delegation=False,
        max_iter=MAX_ITERATIONS,
    )


ANALYST = build_analyst_agent()


# ══════════════════════════════════════════════════════════════════════════════
# 4.  LangGraph Node Functions
# ══════════════════════════════════════════════════════════════════════════════

def node_react_loop(state: ReActState) -> ReActState:
    """
    The core ReAct node.
    Runs the CrewAI analyst with a structured ReAct prompt.
    CrewAI's internal loop handles Thought→Action→Observation natively
    when given tools — we capture the full trace here.
    """
    question  : str           = state["question"]
    steps     : List[ReActStep] = state["steps"]
    iteration : int           = state["iteration"]

    # Build context from prior steps
    prior_context = ""
    if steps:
        prior_context = "\n\nPrior reasoning trace:\n"
        for s in steps:
            prior_context += (
                f"\n[Iteration {s.iteration}]\n"
                f"Thought: {s.thought}\n"
                f"Action: {s.action}\n"
                f"Observation: {s.observation[:300]}...\n"
            )

    task_description = textwrap.dedent(f"""
        You are operating in ReAct mode: Reason, then Act, then Observe, then Reason again.
        
        INVESTOR QUESTION:
        {question}
        {prior_context}
        
        Instructions:
        1. Start with a clear THOUGHT: explain what information you need and why
        2. Take exactly ONE ACTION using your available tools
        3. Review the OBSERVATION and decide if you need more data
        4. Repeat until you have enough to give a complete, confident answer
        5. End with a structured FINAL ANSWER covering:
           - Direct answer to the question (1-2 sentences)
           - Supporting data points (bullet list)
           - Key risks or caveats
           - Investment implication
        
        Available tools: get_financials, get_debt_maturity, get_interest_rate, 
                         get_stock_price, compare_competitors
        
        Be precise. Cite specific numbers from tool outputs.
    """)

    task = Task(
        description     = task_description,
        expected_output = (
            "A complete ReAct trace ending with a structured FINAL ANSWER "
            "that directly addresses the investor's question with specific data."
        ),
        agent = ANALYST,
    )

    crew   = Crew(agents=[ANALYST], tasks=[task], process=Process.sequential, verbose=False)
    result = crew.kickoff()

    raw_output = str(result).strip()

    # Parse the output into a ReActStep for our trace
    # (CrewAI handles internal T→A→O; we record the final exchange)
    step = ReActStep(
        thought     = "Agent performed multi-step ReAct reasoning (see final answer)",
        action      = "Multiple tool calls (get_financials, get_interest_rate, etc.)",
        observation = raw_output[:500],
        iteration   = iteration + 1,
    )

    return {
        **state,
        "steps"       : steps + [step],
        "iteration"   : iteration + 1,
        "is_done"     : True,
        "final_answer": raw_output,
    }


def node_check_done(state: ReActState) -> ReActState:
    """Safety valve — force stop if max iterations hit."""
    if state["iteration"] >= MAX_ITERATIONS and not state["is_done"]:
        best = state["steps"][-1].observation if state["steps"] else "No data collected."
        return {
            **state,
            "is_done"     : True,
            "final_answer": f"[Max iterations reached]\n\nBest available answer:\n{best}",
        }
    return state


def node_finalize(state: ReActState) -> ReActState:
    """Format and print the final output."""
    print("\n" + "═" * 70)
    print("REACT AGENT — FINAL ANSWER")
    print("═" * 70)
    print(state["final_answer"])
    print("═" * 70)
    return state


# ══════════════════════════════════════════════════════════════════════════════
# 5.  Routing
# ══════════════════════════════════════════════════════════════════════════════

def route_after_react(state: ReActState) -> str:
    if state["is_done"] or state["iteration"] >= MAX_ITERATIONS:
        return "finalize"
    return "check_done"


def route_after_check(state: ReActState) -> str:
    if state["is_done"]:
        return "finalize"
    return "react_loop"


# ══════════════════════════════════════════════════════════════════════════════
# 6.  Build the LangGraph State Machine
# ══════════════════════════════════════════════════════════════════════════════

def build_react_graph() -> Any:
    """
    ReAct Graph:

        START → react_loop → check_done ──(done)──→ finalize → END
                    ↑             │
                    └─(not done)──┘
    """
    builder = StateGraph(ReActState)

    builder.add_node("react_loop",  node_react_loop)
    builder.add_node("check_done",  node_check_done)
    builder.add_node("finalize",    node_finalize)

    builder.add_edge(START, "react_loop")

    builder.add_conditional_edges(
        "react_loop",
        route_after_react,
        {"finalize": "finalize", "check_done": "check_done"},
    )

    builder.add_conditional_edges(
        "check_done",
        route_after_check,
        {"finalize": "finalize", "react_loop": "react_loop"},
    )

    builder.add_edge("finalize", END)

    return builder.compile()


# ══════════════════════════════════════════════════════════════════════════════
# 7.  Public API
# ══════════════════════════════════════════════════════════════════════════════

def ask_stock_analyst(question: str) -> str:
    """
    Main entry-point.
    Pass any natural-language investment question and get a data-backed answer.
    """
    print("═" * 70)
    print(f"ReAct Stock Research Agent")
    print(f"Question: {question}")
    print("═" * 70 + "\n")

    graph         = build_react_graph()
    initial_state = make_initial_state(question)
    final_state   = graph.invoke(initial_state)

    return final_state.get("final_answer", "No answer produced.")


# ══════════════════════════════════════════════════════════════════════════════
# 8.  Demo — Three Different Question Types
# ══════════════════════════════════════════════════════════════════════════════

DEMO_QUESTIONS = [
    # Debt + macro question (the use case from the explanation)
    "Should I be concerned about NVIDIA's debt levels given the current interest rate environment?",

    # Valuation + competitive question
    # "Is AMD fairly valued compared to NVIDIA and Intel right now?",

    # Risk + momentum question
    # "What are the key risks for Apple stock over the next 6 months?",
]

if __name__ == "__main__":
    for q in DEMO_QUESTIONS:
        answer = ask_stock_analyst(q)
        print("\n")
